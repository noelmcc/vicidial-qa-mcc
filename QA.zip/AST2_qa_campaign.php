<?php
### AST2_qa_campaign.php
### 
# created 02-28-2017 Noel Cruz <noel@mycallcloud.com>
### 
### 

session_start();

header ("Content-type: text/html; charset=utf-8");

require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");

?>
<html>
<head>
<title></title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<link href="https://fonts.googleapis.com/css?family=News+Cycle:400,700" rel="stylesheet">
<style type="text/css">
	html body, table {
		font-family: 'News Cycle'; 
		font-size: 18px;
	}
	html select, input {
		font-family: 'News Cycle'; 
		font-size: 13px;
	}
</style>
<!-- start imports and script for datepicker mcc_edits_start_12-12-2016 -->

<!-- css style for option field witdh -->
<style>
#opfield{
 width:365px;   
}

</style>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    var dateFormat = "mm/dd/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "+0w",
          changeMonth: true,
          numberOfMonths: 1
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "+0w",
        changeMonth: true,
        numberOfMonths: 1
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
  } );
  </script>
  
</script>

</head>
<body bgcolor="#d9e6fe" marginheight="5" marginwidth="0" leftmargin="0" topmargin="5">
<center>
<table width="50%" bgcolor="#d9e6fe" cellpadding="10" cellspacing="0">

	<?php

	echo "<tr bgcolor=\"#f0f5fe\">\n";
		echo "<td align=left colspan=2>\n";

		//start search form mcc_edits_start_12_12_2016
		
		echo "<form name=\"searchutility\" action=\"AST2_qa_campaign_results.php\" method=\"post\"> \n";
		
			echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" border = \"0\">\n";
				echo "<tr>\n";
					echo "<td align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"2\">\n";
						echo "<b>Select a Call Date Range</b> <font size =\"-1\">Click fields to select dates (recommended range is within 30 days)</font>\n";
					echo "</td>";
				echo "</tr>";
				
				// start date range picker with pre-filled dates mcc_edits_start_12_12_2016
				
				$currdt = date("Y-m-d h:m:s");
				$mindt = date("Y-m-d", strtotime('-30 days'));			//set min date to 30 days from current date
				
				echo "<tr>";
					echo "<td bgcolor=\"#B9CBFD\" width = \"15\">";
						echo "&nbsp; \n";
					echo "</td>";
					echo "<td align=\"center\" bgcolor=\"#B9CBFD\">\n";
						echo "<label for=\"from\">From: </label> \n";
						echo "<input type=\"text\" id=\"from\" name=\"datefrom\" value = \"".$mindt." 00:00:00\"> \n";
						echo "<label for=\"to\"> To: </label> \n";
						echo "<input type=\"text\" id=\"to\" name=\"dateto\" value = \"".$currdt."\"> \n";
					echo "</td>";
				echo "</tr>";
				
				// end date range picker mcc_edits_end_12_12_2016
				
				//search panel start
				
				echo "<tr>\n";
					echo "<td align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"2\">\n";
						echo "<b>Select Campaign</b><font size =\"-1\"> Default is all campaigns.</font>\n";
					echo "</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td bgcolor=\"#B9CBFD\" width = \"15\">";
						echo "&nbsp; \n";
					echo "</td>";
					echo "<td align=\"center\" bgcolor=\"#B9CBFD\">\n";
					echo "<select name=\"campaigns\" id = \"opfield\"> \n";
						
					echo "<option value=\"allcamps\" selected = \"selected\">ALL CAMPAIGNS</option> \n";
					
					$result1 = mysql_query("SELECT * FROM vicidial_campaigns ORDER BY campaign_id") or die(mysql_error()); 
						while ($row1 = mysql_fetch_array($result1)){
							$campid = $row1['campaign_id'];
							$camp_name = $row1['campaign_name'];	
						
						echo "<option value=\"".$campid."\">".$campid." - ".$camp_name."</option> \n";
						}

						echo "</select> \n";
					echo "</td>";
				echo "</tr>";
				
				//search panel end
				
				echo "<tr> \n";
					echo "<td align=\"center\" bgcolor=\"#015B91\" colspan = \"2\">\n";
						echo "<input type=\"hidden\" name=\"pagestart\" value=\"0\" />\n";
						echo "<input type=\"hidden\" name=\"pagemax\" value=\"50\" />\n";
						echo "<input type=\"submit\" value=\"Begin Records Search\" /> \n";
						echo "<input type=\"reset\" value=\"Reset Form\" /> \n";
					echo "</td> \n";
				echo "</tr> \n";

				echo "</table> \n";
		
		echo "</form> \n";
		
?>

