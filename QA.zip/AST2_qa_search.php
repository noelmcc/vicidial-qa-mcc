<?php
### AST2_qa_search.php
### 
###
# Reports landing page
# Created 02-27-2017 by Noel Cruz <noel@mycallcloud.com>
###

session_start();

header ("Content-type: text/html; charset=utf-8");

/* require db connection script */
require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");



?>
<html>
<head>
<title>VICIDIAL ADMIN: QA Reports</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<link href="https://fonts.googleapis.com/css?family=News+Cycle:400,700" rel="stylesheet">
<style type="text/css">
	html body {
		font-family: 'News Cycle';
		font-size: 15px;
	}
</style>
<style type="text/css">
	a {
		text-decoration: none
	}
	a:visited { 
		color: black; 
	}
	a:hover { 
		color: red; 
	}
</style>	
<!-- accordion menu script -->
<style>
button.accordion {
    background-color: #B9CBFD;
    color: #444;
    cursor: pointer;
    padding: 0 0 0 5px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
	font-family: 'News Cycle';
    font-size: 17px;
	font-weight: bold;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #9BB9FB;
}

button.accordion:after {
    content: '\002B';
    color: #777;
    font-weight: bold;
	font-size: smaller;
    float: right;
    margin-left: 5px;
}

button.accordion.active:after {
    content: "\2212";
}

div.panel {
    padding: 1 18px;
    background-color: #c5dafe;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}

button.static { 
    background-color: #B9CBFD;
    padding: 5px;
    width: 100%;
    border: none;
    outline: none;
    transition: 0.4s;
}

div.staticpanel {
    padding: 0 0px;
    background-color: #D9E6FE;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}

</style>

</head>
<BODY BGCOLOR="#f2f6ff" marginheight="5" marginwidth="0" leftmargin="0" topmargin="5">

<table width = "1350" align = "center" cellspacing = "0" cellpadding = "3" BGCOLOR="#D9E6FE" border = "0">
	<tr bgcolor="#015B91">
		<td valign = "top" align = "left">
			<font color = "white"><b><a href="./admin.php"><span style="color: #ffffff; text-decoration: none;" >VICIDIAL ADMIN</span></a>: QA Utilities</b></font>
		</td>
		<td align = "right">
			<font color = "white"><b><?php echo date("l F j, Y h:m:s A") ?></b></font>
		</TD>
	</tr>
	<tr>
		<td valign = "top" align = "left" width = "200" bgcolor = "#c5dafe">
			<button class="accordion"><b>QA Evaluations</b></button>
				<div class="panel">
					<a href="AST2_qa_campaign.php" target = "result">Campaign</a><br>
					<a href="AST2_qa_agent.php" target = "result">Agent</a><br>
					<a href="AST2_qa_usergroup.php" target = "result">User Group</a><br>
					<a href="AST2_qa_ingroup.php" target = "result">InGroup</a><br>
					<a href="AST2_qa_supervisor.php" target = "result">Supervisor</a><br>
					<a href="AST2_qa_campaignstatus.php" target = "result">Campaign Status</a>
					<a href="AST2_qa_evaluated.php" target = "result">Evaluated</a>
				</div>

			<button class="accordion"><b>QA Reporting</b></button>
				<div class="panel">
					Yearly<br>
					Monthly<br>
					Weekly<br>
					Daily
				</div>
				
			<button class="accordion"><b>QA Editor</b></button>
				<div class="panel">
					Campaign<br>
					Scoring
				</div>

			<button class="static"></button>
				<div class="panel">
					
				</div>

			<script>
				var acc = document.getElementsByClassName("accordion");
				var i;

				for (i = 0; i < acc.length; i++) {
					acc[i].onclick = function() {
					this.classList.toggle("active");
					var panel = this.nextElementSibling;
						if (panel.style.maxHeight){
							panel.style.maxHeight = null;
						} else {
							panel.style.maxHeight = panel.scrollHeight + "px";
						} 
					}
				}
			</script>
		</td>
		<td valign = "top" align = "center">
			<iframe name="result" allowtransparency="true" src="AST2_qa_campaign.php" width="100%" height="670" frameborder="0" style="background-color: #015B91 display: block;" scrolling="no">
		</td>
	</tr>
</table>

</body>
</html>