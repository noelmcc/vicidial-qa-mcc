<?
$recurl1 = "http://v17.mycallcloud.com";			//change this to the public address for the recording files
$recurl2 = "http://v18.mycallcloud.com";			//change this to the public address for the recording files





//add more servers as needed; use var format as shown
?>