<?php
header ("Content-type: text/html; charset=utf-8");

require("dbconnect.php");

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}

	$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$auth=$row[0];

$fp = fopen ("./project_auth_entries_qa.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");
$pagename = basename($_SERVER['PHP_SELF']);

  if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
	{
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
	}
  else
	{

	if($auth>0)
		{
			$stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
			$rslt=mysql_query($stmt, $link);
			$row=mysql_fetch_row($rslt);
			$LOGfullname=$row[0];
		fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|$pagename|\n");
		fclose($fp);
		}
	else
		{
		fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$pagename|\n");
		fclose($fp);
		}

	$stmt="SELECT full_name from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$full_name = $row[0];

	}

		
	
?>

<htmL>
<head>
<title>VICIDIAL ADMIN: Save Evaluation</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<style>
body {
	font-family: Arial, Helvetica;
}

</style>


</head>

<BODY BGCOLOR="white" marginheight="5" marginwidth="5" leftmargin="5" topmargin="5">
<TABLE WIDTH="100%" BGCOLOR="#D9E6FE" cellpadding="10" cellspacing="0" border = "0">
	<TR BGCOLOR="#015B91">
		<TD ALIGN="LEFT">
			<FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>VICIDIAL ADMIN</a>: Manual Update</font>
		</TD>
	</TR> 
	<TR BGCOLOR="#F0F5FE">
		<td align = "CENTER"> 
		
			<?php

			$cdsrc = mysql_query("SELECT MAX(call_date) as last_call_date FROM vicidial_agent_comments ");
				$rowcd = mysql_fetch_array($cdsrc);
				$last_call_date = $rowcd['last_call_date'];
	
			$dbsrc = 	mysql_query("select event_time,uniqueid,user,user_group,campaign_id,status,lead_id from vicidial_agent_log where talk_sec > '5' and event_time > '$last_call_date' ");
				while ($rowsrc = mysql_fetch_array($dbsrc)) {
					$call_date = $rowsrc['event_time'];
					$uniqueid = $rowsrc['uniqueid'];
					$lead_id = $rowsrc['lead_id'];
					$user = $rowsrc['user'];
					$user_group = $rowsrc['user_group'];
					$status = $rowsrc['status'];
					$campaign_id = $rowsrc['campaign_id'];
		
					mysql_query("INSERT INTO vicidial_agent_comments 
						(call_date,
						uniqueid,
						lead_id,
						user,
						user_group,
						ingroup,
						call_status,
						campaign_id) 
					VALUES
						('$call_date', 
						'$uniqueid', 
						'$lead_id', 
						'$user', 
						'$user_group',
						'',
						'$status',
						'$campaign_id') ") 
					or die(mysql_error());  

				$cidsrc = mysql_query("SELECT campaign_name,active FROM vicidial_campaigns WHERE campaign_id = '$campaign_id' ");
					$rowcid = mysql_fetch_array($cidsrc);
					$campname = $rowcid['campaign_name'];
					$active = $rowcid['active'];
		
				$fnsrc = mysql_query("SELECT full_name FROM vicidial_users WHERE user = '$user' ");
					$rowsrc = mysql_fetch_array($fnsrc);
					$full_name = $rowsrc['full_name'];
		
					mysql_query("UPDATE vicidial_agent_comments SET campaign_name = '$campname' WHERE campaign_id = '$campaign_id' ");
					mysql_query("UPDATE vicidial_agent_comments SET active = '$active' WHERE user = '$user' ");
					mysql_query("UPDATE vicidial_agent_comments SET full_name = '$full_name' WHERE user = '$user' ");
					//mysql_query("UPDATE vicidial_agent_comments,vicidial_closer_log SET vicidial_agent_comments.ingroup = vicidial_closer_log.campaign_id WHERE vicidial_agent_comments.user = vicidial_closer_log.user AND vicidial_agent_comments.uniqueid = vicidial_closer_log.uniqueid");
		
				}

				echo "Successfully Updated!<br><br> \n";

		echo "</td> \n";
	echo "</tr> \n";
	
	echo "<tr bgcolor = \"#015B91\"> \n";
		echo "<td align = \"center\" valign=\"top\"> \n";
			echo "<INPUT TYPE=\"button\" VALUE=\"Click to Close\" onClick=\"window.opener.location.reload();window.close();\"> \n";
		echo "</td> \n";
	echo "</tr> \n";
	
echo "</table> \n";
				
			
			
			
			
			

			?>
		
		
