<?php
### AST2_qa_campaign_results.php
### 
# created 02-28-2017 Noel Cruz <noel@mycallcloud.com>
### 
### 

require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");

/* POST, SESSION, and GET scripts go here */

/* print_r($_POST);
print_r($_GET);
print_r($_SESSION); */

if (isset($_GET["user"]))				{$user=$_GET["user"];}
	elseif (isset($_POST["user"]))		{$user=$_POST["user"];}

if (isset($_GET["full_name"]))				{$full_name=$_GET["full_name"];}
	elseif (isset($_POST["full_name"]))		{$full_name=$_POST["full_name"];}

if (isset($_GET["campaign_id"]))				{$campaign_id=$_GET["campaign_id"];}
	elseif (isset($_POST["campaign_id"]))		{$campaign_id=$_POST["campaign_id"];}

if (isset($_GET["uniqueid"]))				{$uniqueid=$_GET["uniqueid"];}
	elseif (isset($_POST["uniqueid"]))		{$uniqueid=$_POST["uniqueid"];}

if (isset($_GET["ingroup"]))				{$ingroup=$_GET["ingroup"];}
	elseif (isset($_POST["ingroup"]))		{$ingroup=$_POST["ingroup"];}

if (isset($_GET["lead_id"]))				{$lead_id=$_GET["lead_id"];}
	elseif (isset($_POST["lead_id"]))		{$lead_id=$_POST["lead_id"];}

if (isset($_GET["call_date"]))				{$call_date=$_GET["call_date"];}
	elseif (isset($_POST["call_date"]))		{$call_date=$_POST["call_date"];}

if (isset($_GET["comment_date"]))				{$comment_date=$_GET["comment_date"];}
	elseif (isset($_POST["comment_date"]))		{$call_date=$_POST["comment_date"];}

if (isset($_GET["phone_number"]))				{$phone_number=$_GET["phone_number"];}
	elseif (isset($_POST["phone_number"]))		{$phone_number=$_POST["phone_number"];}

if (isset($_GET["supervisor_id"]))				{$supervisor_id=$_GET["supervisor_id"];}
	elseif (isset($_POST["supervisor_id"]))		{$supervisor_id=$_POST["supervisor_id"];}

if (isset($_GET["location"]))				{$location=$_GET["location"];}
	elseif (isset($_POST["location"]))		{$location=$_POST["location"];}

if (isset($_GET["filename"]))				{$filename=$_GET["filename"];}
	elseif (isset($_POST["filename"]))		{$filename=$_POST["filename"];}


?>

<html>
<head>
<title></title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<link href="https://fonts.googleapis.com/css?family=News+Cycle:400,700" rel="stylesheet">
<style type="text/css">
	html body {
		font-family: 'News Cycle'; 
		font-size: 13.5px;
	}
	tr.listing:hover {
		background-color: #cccccc;
	}
	table {
		font-family: 'News Cycle'; 
		font-size: 13.5px;
	}
	.innerscroll {
		max-height: 456px;
		overflow: auto;
	}
</style>

<!-- audio player js script start -->
<script src="styles/audio.min2.js"></script>
<!-- audio player js script end -->

</head>
<body bgcolor="#d9e6fe" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">

<?php

echo "<table width = \"1120\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" align=\"left\">\n";
	echo "<tr>\n";
		echo "<td>\n";

			echo "<table width = \"100%\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" align=\"left\">\n";
				echo "<tr>\n";
					echo "<td colspan=\"5\">\n";

						/* get location and filename of recorded call from recording_log table */
						$chkcallfile = mysql_query("SELECT filename, location FROM recording_log WHERE lead_id = '$lead_id' AND user = '$user' ");
							$rowcallfile = mysql_fetch_array($chkcallfile);
							$callfilename = $rowcallfile['filename'];
							$callfileurl = $rowcallfile['location'];
				
							function file_exists_remote($url) {
								$curl = curl_init($url);
								curl_setopt($curl, CURLOPT_NOBODY, true);
								curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
								//Check connection only
								$result = curl_exec($curl);
								//Actual request
								$ret = false;
								if ($result !== false) {
									$statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
									//Check HTTP status code
									if ($statusCode == 200) {
										$ret = true;   
									}
								}
								curl_close($curl);
								return $ret;
							}
											
							if (empty($callfilename)){
								echo "Recording Filename: <font color = \"red\"><b>NO RECORDING FOUND. You are not allowed to Evaluate this Agent.</b></font><br> \n";
								/* $norec = "1"; */
							} else {
											
								/* check if recorded file exists using url pointers in servers table */
													
								/* explode location to get internal IP for comparison */
								$locparts = explode("/",$callfileurl);
								$recdl = $locparts[2];
								/* echo "part3: ".$locparts[2]."<br>\n"; */
											
								/* get public server names */
								$chksrvname = mysql_query("select external_server_ip from servers where server_ip = '$recdl' and external_server_ip !='' ");
									$rowsrvname = mysql_fetch_array($chksrvname);
									$recfilesrv = $rowsrvname['external_server_ip'];
									$recfileloc = "http://".$recfilesrv."/RECORDINGS/MP3/".$callfilename."-all.mp3";
						
									/* get local server IP address for comparison */
									$servip = $_SERVER['SERVER_ADDR'];
									/* echo "Server IP: ".$servip."<br>\n"; */
						
									/* assign dns domain to player reference url */
									if ($recdl == $servip) {
										$callfileurl = $recfileloc;
									} 
					
									$url = $callfileurl;
									$exist = file_exists_remote($url);
									if($exist) {
										echo "Recording Filename: <b><a href = \"".$recfileloc."\" style=\"text-decoration:none\">".$callfilename."-all.mp3</a></b> <i>(Right-click to download)</i><br>\n";
										echo "<audio src=\"".$callfileurl."\" preload=\"auto\"></audio>\n";		//change audio src to reference from recording table when availalbe */
									} else {
										echo "Recording Filename: <b><a href = \"".$recfileloc."\" style=\"text-decoration:none\">".$callfilename."-all.mp3</a></b> <i>(Right-click to download)</i><br>\n";
										echo "Recording Filename: <font color = \"red\"><b>NO RECORDING FOUND. You are not allowed to Evaluate this Agent.</b></font><br> \n";
									}

							}

					echo "</td>\n";
				echo "</tr>\n";
				echo "<tr>\n";
					echo "<td width=\"15\" align = \"center\" valign=\"top\"> \n";
						echo "<b>No.</b>\n";
					echo "</td>\n";
					echo "<td width=\"80\" align = \"center\" valign=\"top\"> \n";
						echo "<b>Score</b>\n";
					echo "</td>\n";
					echo "<td align=\"center\">\n";
						echo "<b>Question</b>\n";
					echo "</td>\n";
					echo "<td width=\"60\" align=\"center\">\n";
						echo "<b>Autofail?</b>\n";
					echo "</td>\n";
					echo "<td width=\"156\" align=\"center\">\n";
						echo "<b>Review Date</b>\n";
					echo "</td>\n";
				echo "</tr>\n";
			echo "</table>\n";
			
		echo "</td>\n";
	echo "</tr>\n";
	
	echo "<tr>\n";
		echo "<td>\n";

			echo "<div class=\"innerscroll\">\n"; 			//make the table scrollable

				echo "<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" align=\"left\" border=\"0\">\n";
				
				/* get scoresheet details based on campaign_id and status from questions_store */
	
				$chkrecord = mysql_query("select * from questions_store where campaign_id ='$campaign_id' and status='ACTIVE' ");
	
				$i=1;
					while($rowrecord = mysql_fetch_array($chkrecord)) {
			
					if ($i % 2 == 0) {
						$bgcolor = "#9BB9FB";
					} else {
						$bgcolor = "#B9CBFD";
					}

					echo "<tr class = \"listing\" bgcolor = \"".$bgcolor."\">\n";	
		
						/* col 1 numbering */
						echo "<td width=\"18\" align = \"center\" valign=\"top\"> \n";
							echo "<b>".$i."</b>\n";
						echo "</td>\n";
			
						/* col2 get dropdown values with default; check if record has been reviewed or not */
						echo "<td width=\"80\" align = \"center\" valign=\"top\"> \n";
							echo $i."\n";
						echo "</td>\n";
			
						/* col3 get active questions */
						echo "<td align = \"left\" valign=\"top\"> \n";
						
							$chkquestion = mysql_query("select * from questions_store where campaign_id = '$campaign_id' and status='ACTIVE' and seq_num='$i' ");
							$rowquestion = mysql_fetch_array($chkquestion);
							$question = $rowquestion['question'];
						
							echo $question."\n";
						echo "</td>\n";
			
						/* col4 get autofail status */
						echo "<td width=\"60\" align = \"center\" valign=\"top\"> \n";
							
							$chkaf = mysql_query("select * from questions_store where campaign_id = '$campaign_id' and status='ACTIVE' and seq_num='$i' ");
							$rowaf = mysql_fetch_array($chkaf);
							$autofail = $rowaf['autofail'];
							
							if ($autofail == "Y") {
								echo "<font color = \"red\"><b>".$autofail."</b></font>\n";
							} else {
								echo $autofail."\n";
							}
							
						echo "</td>\n";
			
						/* col5 get comment_date */
						echo "<td width=\"140\" align = \"center\" valign=\"top\"> \n";
						
						$chkcd = mysql_query("select * from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date='$call_date' and fscore !='' ");
							$rowcd = mysql_fetch_array($chkcd);
							$comment_date = $rowcd['comment_date'];
							
							echo $comment_date."\n";
						echo "</td>\n";
			
					echo "</tr>\n";
		
					$i++;
					}
					
					echo "<tr>\n";
						echo "<td height=\"350\">\n";

						echo "</td>\n";
					echo "</tr>\n";
		
				echo "</table>\n";
			echo "</div>\n";
			
		echo "</td>\n";
	echo "</tr>\n";
	
	/* echo "<tr>\n";
		echo "<td height=\"350\">\n";

		echo "</td>\n";
	echo "</tr>\n"; */
	
	/* echo "<tr>\n";
		echo "<td height=\"150\">\n";

		echo "</td>\n";
	echo "</tr>\n"; */

echo "</table>\n";


?>


	<!-- audio player script start -->
	<script>
	audiojs.events.ready(function() {
		var as = audiojs.createAll();
	});
	</script>
	<!-- audio player script end -->


</body>
</html>