<?php
### AST2_qa_campaign.php
### 
# created 02-28-2017 Noel Cruz <noel@mycallcloud.com>
### 
### 

session_start();

header ("Content-type: text/html; charset=utf-8");

require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");

/* POST, SESSION, and GET scripts go here */



?>
<html>
<head>
<title></title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<style>
	body {
		font-family: 'News Cycle'; 
	}
</style>
<!-- start imports and script for datepicker mcc_edits_start_12-12-2016 -->

<!-- css style for option field witdh -->
<style>
#opfield{
 width:365px;   
}

#agfield{
 width:365px;   
}

#supfield{
 width:365px;   
}

#ugfield{
 width:365px;   
}

#csfield{
 width:365px;   
}
</style>

</head>
<BODY BGCOLOR="#D9E6FE" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">
<CENTER>
<TABLE WIDTH="100%" BGCOLOR="#D9E6FE" cellpadding="0" cellspacing="0">

	<?php

	echo "<TR BGCOLOR=\"#F0F5FE\">\n";
		echo "<TD ALIGN=LEFT COLSPAN=2>\n";

		//start search form mcc_edits_start_12_12_2016
		
			echo "<form action=\" \" method=\"post\"> \n";
		
				echo "<TABLE width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" border = \"0\">\n";
				
					//results panel start
					
					echo "<tr>\n";
						echo "<td align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"2\">\n";
							echo "<b>Put title here</b><i><font size =\"-1\"> Put Subtitle here</i></font>\n";
						echo "</td>";
					echo "</tr>";
					echo "<tr>";
						echo "<td bgcolor=\"#B9CBFD\" width = \"15\">";
							echo "Results scripting here \n";
						echo "</td>";
					echo "</tr>";
				
					//results panel end
				
					echo "<tr> \n";
						echo "<td align=\"center\" bgcolor=\"#015B91\" colspan = \"2\">\n";
							echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign.php'\" value=\"Back to Search\" /> \n";
						echo "</td> \n";
					echo "</tr> \n";

				echo "</table> \n";
		
			echo "</form> \n";
		
		echo "</td> \n";
	echo "</tr> \n";
echo "</table> \n";
		
?>

</body>
</html>
