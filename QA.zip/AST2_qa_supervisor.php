<?php
### AST2_qa_campaign.php
### 
# created 02-28-2017 Noel Cruz <noel@mycallcloud.com>
### 
### 

session_start();

header ("Content-type: text/html; charset=utf-8");

require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");

?>
<html>
<head>
<title></title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<style>
	body {
		font-family: 'News Cycle'; 
	}
</style>
<!-- start imports and script for datepicker mcc_edits_start_12-12-2016 -->

<!-- css style for option field witdh -->
<style>
#opfield{
 width:365px;   
}

#agfield{
 width:365px;   
}

#supfield{
 width:365px;   
}

#ugfield{
 width:365px;   
}

#csfield{
 width:365px;   
}
</style>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    var dateFormat = "mm/dd/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "+0w",
          changeMonth: true,
          numberOfMonths: 1
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "+0w",
        changeMonth: true,
        numberOfMonths: 1
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
  } );
  </script>
  
</script>

</head>
<BODY BGCOLOR="#D9E6FE" marginheight="5" marginwidth="0" leftmargin="0" topmargin="5">
<CENTER>
<TABLE WIDTH="50%" BGCOLOR="#D9E6FE" cellpadding="10" cellspacing="0">

	<?php

	echo "<TR BGCOLOR=\"#F0F5FE\">\n";
		echo "<TD ALIGN=LEFT COLSPAN=2>\n";

		//start search form mcc_edits_start_12_12_2016
		
		echo "<form name=\"searchutility\" action=\"AST2_qa_supervisor_results.php \" method=\"post\"> \n";
		
			echo "<TABLE width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" border = \"0\">\n";
				echo "<tr>\n";
					echo "<td align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"2\">\n";
						echo "<b>Select a Call Date Range</b> <i><font size =\"-1\">Click fields to select dates (recommended range is within 30 days)*</font></i>\n";
					echo "</td>";
				echo "</tr>";
				
				// start date range picker with pre-filled dates mcc_edits_start_12_12_2016
				
				$currdt = date("Y-m-d h:m:s");
				$mindt = date("Y-m-d", strtotime('-30 days'));			//set min date to 30 days from current date
				
				echo "<tr>";
					echo "<td bgcolor=\"#B9CBFD\" width = \"15\">";
						echo "&nbsp; \n";
					echo "</td>";
					echo "<td align=\"center\" bgcolor=\"#B9CBFD\">\n";
						echo "<label for=\"from\">From: </label> \n";
						echo "<input type=\"text\" id=\"from\" name=\"datefrom\" value = \"".$mindt." 00:00:00\"> \n";
						echo "<label for=\"to\"> To: </label> \n";
						echo "<input type=\"text\" id=\"to\" name=\"dateto\" value = \"".$currdt."\"> \n";
					echo "</td>";
				echo "</tr>";
				
				// end date range picker mcc_edits_end_12_12_2016
				
				//search panel start
				
				echo "<tr>\n";
					echo "<td align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"2\">\n";
						echo "<b>Select QA Specialist</b><i><font size =\"-1\"> Default is all Specialists who has evaluations saved.</font></i>\n";
					echo "</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td bgcolor=\"#B9CBFD\" width = \"15\">";
						echo "&nbsp; \n";
					echo "</td>";
					echo "<td align=\"center\" bgcolor=\"#B9CBFD\">\n";
						echo "<select name=\"specialist\" id = \"supfield\"> \n";
						
						if ($specialistset == "allsups") {
							
							echo "<option value=\"allsups\" selected = \"selected\">ALL SUPERVISORS</option> \n";
							
							$result1d = mysql_query("SELECT DISTINCT supervisor_id as sup_id FROM vicidial_agent_comments WHERE supervisor_id != '' ") or die(mysql_error()); 
							while ($row1d = mysql_fetch_array($result1d)){
								$sup = $row1d['sup_id'];
							
								$result1d2 = mysql_query("SELECT full_name FROM vicidial_users WHERE user = '$sup'") or die(mysql_error()); 
									$row1d2 = mysql_fetch_array($result1d2); 
									$supfn = $row1d2['full_name'];
							
							echo "<option value=\"".$sup."\">".$sup." - ".$supfn."</option> \n";
													
							}
							
						} elseif (empty($specialistset)) {
							
							echo "<option value=\"allsups\" selected = \"selected\">ALL SUPERVISORS</option> \n";
							
							$result1d = mysql_query("SELECT DISTINCT supervisor_id as sup_id FROM vicidial_agent_comments WHERE supervisor_id != '' ") or die(mysql_error()); 
							while ($row1d = mysql_fetch_array($result1d)){
								$sup = $row1d['sup_id'];
							
								$result1d2 = mysql_query("SELECT full_name FROM vicidial_users WHERE user = '$sup'") or die(mysql_error()); 
									$row1d2 = mysql_fetch_array($result1d2); 
									$supfn = $row1d2['full_name'];
							
							echo "<option value=\"".$sup."\">".$sup." - ".$supfn."</option> \n";
							}
													
						} else {
								
							$sup = $specialistset;
							
							echo "<option value=\"allsups\">ALL SUPERVISORS</option> \n";
							echo "<option value=\"".$sup."\" selected = \"selected\">".$sup." - ".$supfn."</option> \n";
							
							$result1d = mysql_query("SELECT DISTINCT supervisor_id AS sup_id FROM vicidial_agent_comments WHERE supervisor_id != '$sup'") or die(mysql_error()); 
							while ($row1d = mysql_fetch_array($result1d)){
								$sup = $row1d['sup_id'];
								
							echo "<option value=\"".$sup."\">".$sup." - ".$supfn."</option> \n";
							
							}

						}
							
						echo "</select> \n";
					echo "</td> \n";
				echo "</tr> \n";
				
				//search panel end
				
				echo "<tr> \n";
					echo "<td align=\"center\" bgcolor=\"#015B91\" colspan = \"2\">\n";
						echo "<input type=\"submit\" value=\"Begin Records Search\" /> \n";
						echo "<input type=\"reset\" value=\"Reset Form\" /> \n";
					echo "</td> \n";
				echo "</tr> \n";

				echo "</table> \n";
		
		echo "</form> \n";
		
?>

