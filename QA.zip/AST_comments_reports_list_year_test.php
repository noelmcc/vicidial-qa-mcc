<?php
// require("dbconnect_mysqli.php");
require("dbconnect.php");

		$chkps = mysql_query("SELECT DISTINCT(campaign_id) FROM vicidial_agent_comments");
		// echo "noah";		
		while($row = mysql_fetch_array($chkps)) {echo $row['campaign_id'] . "</br>";}
		
?>

