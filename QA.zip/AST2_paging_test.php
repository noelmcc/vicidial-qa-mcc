<?php

require("dbconnect.php");

echo "PAGING TEST <br>\n";
echo "initial value pagestart: 0 <br>\n";
echo "initial value pagemax: 50 <br>\n";
echo "pagination increment: 50 <br>\n";

/* set pagemax */
/* $pagemax = 50; */

/* set campaign choice */
if (isset($_GET["campaigns"]))				{$campaigns=$_GET["campaigns"];}
	elseif (isset($_POST["campaigns"]))		{$campaigns=$_POST["campaigns"];}

/* get pagestart sent value */
if (!isset($_GET["pagestart"]))	{$pagestart = 0;} else {$pagestart=$_GET["pagestart"];}

/* get pagemax sent value */
if (!isset($_GET["pagemax"]))	{$pagemax = 50;} else {$pagemax=$_GET["pagemax"];}

echo "+++++++++++++++++++++++++++++++++<br>\n";

/* print sent values */
echo "SENT: \n";
print_r($_POST);
print_r($_GET);
print_r($_SESSION);

echo "<br>\n";
echo "+++++++++++++++++++++++++++++++++<br>\n";
echo "<br>\n";

/* begin form and selection of campaign */

echo "<form action=\"AST2_paging_test.php\" method=\"post\"> \n"; 						//change action target for final version

	echo "<select name=\"campaigns\"> \n";
	
	/* check if campaign is selected */
	if (!empty($campaigns)) {
		echo "<option value=\"".$campaigns."\" selected = \"selected\">".$campaigns."</option> \n";
		echo "<option value=\"allcamps\">ALL CAMPAIGNS</option> \n";
	} else {
		echo "<option value=\"allcamps\" selected = \"selected\">ALL CAMPAIGNS</option> \n";
	}

	$chkcampaign = mysql_query("select * from vicidial_campaigns order by campaign_id");
	
	while($rowcampaign = mysql_fetch_array($chkcampaign)) {
		$campid = $rowcampaign['campaign_id'];
		$campname = $rowcampaign['campaign_name'];	
	
		echo "<option value=\"".$campid."\">".$campid." - ".$campname."</option> \n";
	}
	
	echo "</select>\n";

	/* print results */

	echo "<br>\n";
	echo "<br>\n";
	echo "Page Start (pagestart): ".$pagestart."<br>\n";
	echo "Page Max (pagemax): ".$pagemax."<br>\n";
	echo "Campaign (campaigns): ".$campaigns."<br>\n";

	/* begin entry count */

	if ($campaigns == "allcamps") {
		$chkpagecount = mysql_query("select count(*) as maxcount from vicidial_agent_comments");
	} else {
		$chkpagecount = mysql_query("select count(*) as maxcount from vicidial_agent_comments where campaign_id = '$campaigns' ");
	}

	$rowpagecount = mysql_fetch_array($chkpagecount);
	$maxcount = $rowpagecount['maxcount'];

	/* print total number of entries */
	echo "Max Count (maxcount): ".number_format($maxcount)."<br>\n";
	
	/* get total number of paging */
	$pagecount = ($maxcount / $pagemax);
	
	/* print results */
	echo "Raw No. of Pages (pagecount): ".$pagecount."<br>\n";
	
	/* round-down page count */
	$pagecountmin = round($pagecount, 0, PHP_ROUND_HALF_DOWN);
	
	/* print results */
	echo "No. of Whole Pages (pagecountmin): ".number_format($pagecountmin)."<br>\n";
	
	/* compare page counts */
	if ($pagecount == $pagecountmin) {
		echo "Page Count Compare: Same Count <br>\n";
	} else {
		$newpagecount = ($pagecountmin + 1);
		echo "New Page Count (newpagecount): ".number_format($newpagecount)."<br>\n";
		$endpagecount = round((round($pagecount, 0, PHP_ROUND_HALF_DOWN) / 100), 0, PHP_ROUND_HALF_DOWN);
		echo "End Page Count (endpagecount): ".$endpagecount."<br>\n";
		$lastpagecount = ($endpagecount * 100);
		echo "Last Page Count (lastpagecount): ".number_format($lastpagecount)."<br>\n";
	}

	/* begin pagination script */
	
	if ($pagestart > 0){
		$newpagestart = ($pagestart + 50);
		$prevpage = ($pagestart - 50);
		
		echo "<br>\n";
		echo "Page Start (pagestart): ".$pagestart."<br>\n";
		echo "New Page Start (newpagestart): ".$newpagestart."<br>\n";
		echo "Page Previous (prevpage): ".$prevpage."<br>\n";
		echo "<br>\n";
		
		/* check and stop pagination if limits reached */
		
		if ($newpagestart < $newpagecount) {
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&campaigns=".$campaigns."'\" value=\"First\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$prevpage."&campaigns=".$campaigns."'\" value=\"Previous\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&pagemax=all&campaigns=".$campaigns."'\" value=\"All\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$newpagestart."&campaigns=".$campaigns."'\" value=\"Next\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$lastpagecount."&campaigns=".$campaigns."'\" value=\"Last\"/>\n";
		} elseif ($newpagestart >= $lastpagecount) {
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&campaigns=".$campaigns."'\" value=\"First\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$prevpage."&campaigns=".$campaigns."'\" value=\"Previous\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&pagemax=all&campaigns=".$campaigns."'\" value=\"All\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Next\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Last\" disabled/>\n";
		}
		
	} else {
		$newpagestart = ($pagestart + 50);
		
		echo "<br>\n";
		echo "Page Start (pagestart): ".$pagestart."<br>\n";
		echo "New Page Start (newpagestart): ".$newpagestart."<br>\n";
		echo "Page Previous (prevpage): NONE<br>\n";
		echo "<br>\n";
		
		if ($pagemax == "all") {
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&campaigns=".$campaigns."'\" value=\"First\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Previous\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"All\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Next\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Last\" disabled/>\n";
		} else {
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"First\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php'\" value=\"Previous\" disabled/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=0&pagemax=all&campaigns=".$campaigns."'\" value=\"All\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$newpagestart."&campaigns=".$campaigns."'\" value=\"Next\"/>\n";
			echo "<input type =\"button\" onclick=\"location.href='AST2_paging_test.php?pagestart=".$lastpagecount."&campaigns=".$campaigns."'\" value=\"Last\"/>\n";
		}
	}
	
	
	
echo "<br>\n";
echo "<br>\n";
echo "<input type=\"submit\" value=\"Begin Records Search\" />\n";
echo "<input type=\"reset\" value=\"Reset Form\" />\n";

echo "</form>\n";





echo "<input type =\"button\" onclick=\"javascript:pop()\" value=\"First\"/>\n";








?>

<script language="JavaScript">
function pop(){
alert("first");
}
</script>
<br><br>
<input type="button" onClick="document.getElementById('theSubmitButton').click();" value="button to click another button">

<br>

<input type="button" name="theSubmitButton" id="theSubmitButton" value="Button to be clicked" onClick="alert('This button was clicked.');">