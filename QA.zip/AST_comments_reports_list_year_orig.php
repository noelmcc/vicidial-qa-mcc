<?php
### AST_comments_reports_list_year.php
### 
### Special thanks to Yiannos Katsirintakis <janokary@gmail.com> for the base code.    www.publicissue.gr LICENSE: GPLv2
###
# 
# edited 01-09-2017 noel cruz noel@mycallcloud.com

session_start();

header ("Content-type: text/html; charset=utf-8");

require("dbconnect.php");

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}

	$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 6 and view_reports='1';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$auth=$row[0];

$fp = fopen ("./project_auth_entries_qa.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");
$pagename = basename($_SERVER['PHP_SELF']);

  if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
	{
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
	}
  else
	{

	if($auth>0)
		{
			$stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
			$rslt=mysql_query($stmt, $link);
			$row=mysql_fetch_row($rslt);
			$LOGfullname=$row[0];
		fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|$pagename|\n");
		fclose($fp);
		}
	else
		{
		fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$pagename|\n");
		fclose($fp);
		}

	$stmt="SELECT full_name from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$full_name = $row[0];

	}
	
	$currdt = date("Y-m-d");

	//start getting POST data from AST_comments_reports_pick.php
	
	if (empty($_POST['post_search'])) {$post_search = $_SESSION['post_search'];
	} else {$post_search = $_POST['post_search'];}
	
	if (empty($_POST['year'])) {$year = $_SESSION['year'];
	} else {$year = $_POST['year'];}

	if (empty($_POST['campaigns'])) {$campaigns = $_SESSION['campaigns'];
	} else {$campaigns = $_POST['campaigns'];}

	if (empty($_POST['agentid'])) {$agentid = $_SESSION['agentid'];
	} else {$agentid = $_POST['agentid'];}

	if (empty($_POST['agentname'])) {$agentname = $_SESSION['agentname'];
	} else {$agentname = $_POST['agentname'];}
	
	if (empty($_POST['usergroups'])) {$usergroups = $_SESSION['usergroups'];
	} else {$usergroups = $_POST['usergroups'];}

	if (empty($_POST['specialist'])) {$specialist = $_SESSION['specialist'];
	} else {$dateto = $_POST['specialist'];}
	
	//compute for years
	
	$currdt = date("Y");
	//$currdt = "2016";
	$mindt1 = date("Y", strtotime('-1 year'));
	$mindt2 = date("Y", strtotime('-2 years'));
	$curryearstart = $currdt."-01-01 00:00:00 ";
	$curryearend = $currdt."-12-31 23:59:59 ";
	$year1start = $mindt1."-01-01 00:00:00 ";
	$year1end = $mindt1."-12-31 23:59:59 ";
	$year2start = $mindt2."-01-01 00:00:00 ";
	$year2end = $mindt2."-12-31 23:59:59 ";
	
	if ($year == "currentyear") {
		$datefrom = $curryearstart;
		$dateto = $curryearend;
	} elseif ($year == "1year") {
		$datefrom = $year1start;
		$dateto = $year1end;
		$currdt = $mindt1;
	} elseif ($year == "2year") {
		$datefrom = $year2start;
		$dateto = $year2end;
		$currdt = $mindt2;
	}

	//test outputs
	
	/* echo "<font size = \"+1\">post_search: ".$post_search."</font><br>";
	echo "<font size = \"+1\">datefrom: ".$datefrom."</font><br>";
	echo "<font size = \"+1\">dateto: ".$dateto."</font><br>";
	echo "<font size = \"+1\">campaigns: ".$campaigns."</font><br>";
	echo "<font size = \"+1\">agentid: ".$agentid."</font><br>";
	echo "<font size = \"+1\">agentname: ".$agentname."</font><br>";
	echo "<font size = \"+1\">usergroups: ".$usergroups."</font><br>";
	echo "<font size = \"+1\">specialist: ".$specialist."</font><br>";
	echo "<font size = \"+1\">currdt: ".$currdt."</font><br>"; */
	
	//end getting POST data from AST_comments_reports_pick.php
	
	//start start getting db details based on post
	
	if ($post_search == "all") {
		$chkps = mysql_query("SELECT COUNT(DISTINCT campaign_id) as cidcount FROM vicidial_agent_comments WHERE call_date BETWEEN '$datefrom' AND '$dateto' ");
			$rowps = mysql_fetch_array($chkps);
			$panelcount = $rowps['cidcount'];
			//echo "<font size = \"+1\">panelcount: ".$panelcount."";
	} elseif ($post_search == "ca") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_ag") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user = '$agentid' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_ag_an") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user = '$agentid' AND full_name = '$agentname' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_ag_an_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user = '$agentid' AND full_name = '$agentname' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_ag_an_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user = '$agentid' AND full_name = '$agentname' AND user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag_an") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND full_name = '$agentname' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag_an_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND full_name = '$agentname' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag_an_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND full_name = '$agentname' AND user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ag_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND supervisor_id = '$specialist' AND '$dateto' ");
	} elseif ($post_search == "ag_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND call_date BETWEEN '$datefrom' AND supervisor_id = '$specialist' AND '$dateto' ");
	} elseif ($post_search == "ag_an_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user = '$agentid' AND full_name = '$agentname' AND call_date BETWEEN '$datefrom' AND supervisor_id = '$specialist' AND '$dateto' ");
	} elseif ($post_search == "an_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE full_name = '$agentname' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "an") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE full_name = '$agentname' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "an_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE full_name = '$agentname' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "an_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE full_name = '$agentname' AND user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_an") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND full_name = '$agentname' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_an_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND full_name = '$agentname' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_an_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND full_name = '$agentname' AND user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_us") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user_group = '$usergroups' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_us_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND user_group = '$usergroups' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
	} elseif ($post_search == "ca_an_sp") {
		$chkps = mysql_query("SELECT * FROM vicidial_agent_comments WHERE campaign_id = '$campaigns' AND full_name = '$agentname' AND supervisor_id = '$specialist' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
}
	
	
	
		
?>
<html>
<head>
<title>VICIDIAL ADMIN: QA Reports - Yearly</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<style>
body {
	font-family: Arial, Helvetica;
	font-size: 8px;
}
</style>
<style type="text/css" media="print">
	.NonPrintable
	{
	display: none;
	}
</style>
<style type="text/css">
	table.tblText tr td
	{
		font-size: 12px;
	}
</style>
<!-- tabbed table start -->
<link rel="stylesheet" href="styles/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php
echo "<script> \n";
	echo "$( function() { \n";
		echo "$( \"#tabs\" ).tabs({ \n";
			echo "create: function( event, ui ) { \n";
				echo "drawStuff1(); \n";
				echo "drawTable1(); \n";
				/* echo "drawTableb1(); \n"; */
				echo "},	 \n";
			echo "activate: function( event, ui ) { \n";
			echo "var panelid = ui.newPanel.attr('id'); \n";
			echo "if (panelid == 'tabs-1') { \n";
				echo "drawStuff1(); \n";
				echo "drawTable1(); \n";
				/* echo "drawTableb1(); \n"; */
			
			$p = 1;
			while($p <= $panelcount) {
				echo "} else if (panelid == 'tabs-".$p."') { \n";
					echo "drawStuff".$p."(); \n";
					echo "drawTable".$p."(); \n";
					/* echo "drawTableb".$p."(); \n"; */
			$p++;
			}
				
			echo "} \n";
			echo "} \n";
		echo "}); \n";
	echo "} ); \n";
echo "</script>   \n";
?>
<!-- tabbed table end -->

<!-- google charts start -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
	google.charts.load('current', {'packages':['bar']});
	google.charts.setOnLoadCallback(drawStuff1);

<?php

	$chkccamp = mysql_query("SELECT DISTINCT campaign_id FROM vicidial_agent_comments WHERE call_date BETWEEN '$datefrom' AND '$dateto' ORDER BY campaign_id ");
		$cc=1;
		while($rowccamp = mysql_fetch_array($chkccamp)) {
			$campaign_id = $rowccamp['campaign_id'];
	  
       echo "function drawStuff".$cc."() { \n";
        echo "var data = new google.visualization.arrayToDataTable([ \n";
          echo "['Month', 'Evals', 'Passes', 'Fails'], \n";
		  
		$chkagent1 = mysql_query("select count(distinct user) as agcount1 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-01%' ");
			$rowagent1 = mysql_fetch_array($chkagent1);
			$agcount1 = $rowagent1['agcount1'];
		$chkevals1 = mysql_query("select count(fscore) as evcount1 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-01%' and fscore != '(NULL)' ");
			$rowevals1 = mysql_fetch_array($chkevals1);
			$evcount1 = $rowevals1['evcount1'];
		$chkpass1 = mysql_query("select count(fscore) as pscount1 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-01%' and fscore = 'PASS' ");
			$rowpass1 = mysql_fetch_array($chkpass1);
			$pscount1 = $rowpass1['pscount1'];
		$chkfail1 = mysql_query("select count(fscore) as flcount1 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-01%' and fscore = 'FAIL' ");
			$rowfail1 = mysql_fetch_array($chkfail1);
			$flcount1 = $rowfail1['flcount1'];
		  
          echo "['January', ".$evcount1.", ".$pscount1.", ".$flcount1."], \n";
		  
		  $chkagent2 = mysql_query("select count(distinct user) as agcount2 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-02%' ");
			$rowagent2 = mysql_fetch_array($chkagent2);
			$agcount2 = $rowagent2['agcount2'];
		$chkevals2 = mysql_query("select count(fscore) as evcount2 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-02%' and fscore != '(NULL)' ");
			$rowevals2 = mysql_fetch_array($chkevals2);
			$evcount2 = $rowevals2['evcount2'];
		$chkpass2 = mysql_query("select count(fscore) as pscount2 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-02%' and fscore = 'PASS' ");
			$rowpass2 = mysql_fetch_array($chkpass2);
			$pscount2 = $rowpass2['pscount2'];
		$chkfail2 = mysql_query("select count(fscore) as flcount2 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-02%' and fscore = 'FAIL' ");
			$rowfail2 = mysql_fetch_array($chkfail2);
			$flcount2 = $rowfail2['flcount2'];
		  
          echo "['February', ".$evcount2.", ".$pscount2.", ".$flcount2."], \n";
          
		  $chkagent3 = mysql_query("select count(distinct user) as agcount3 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-03%' ");
			$rowagent3 = mysql_fetch_array($chkagent3);
			$agcount3 = $rowagent3['agcount3'];
		$chkevals3 = mysql_query("select count(fscore) as evcount3 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-03%' and fscore != '(NULL)' ");
			$rowevals3 = mysql_fetch_array($chkevals3);
			$evcount3 = $rowevals3['evcount3'];
		$chkpass3 = mysql_query("select count(fscore) as pscount3 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-03%' and fscore = 'PASS' ");
			$rowpass3 = mysql_fetch_array($chkpass3);
			$pscount3 = $rowpass3['pscount3'];
		$chkfail3 = mysql_query("select count(fscore) as flcount3 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-03%' and fscore = 'FAIL' ");
			$rowfail3 = mysql_fetch_array($chkfail3);
			$flcount3 = $rowfail3['flcount3'];
		  
          echo "['March', ".$evcount3.", ".$pscount3.", ".$flcount3."], \n";
          
		  $chkagent4 = mysql_query("select count(distinct user) as agcount4 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-04%' ");
			$rowagent4 = mysql_fetch_array($chkagent4);
			$agcount4 = $rowagent4['agcount4'];
		$chkevals4 = mysql_query("select count(fscore) as evcount4 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-04%' and fscore != '(NULL)' ");
			$rowevals4 = mysql_fetch_array($chkevals4);
			$evcount4 = $rowevals4['evcount4'];
		$chkpass4 = mysql_query("select count(fscore) as pscount4 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-04%' and fscore = 'PASS' ");
			$rowpass4 = mysql_fetch_array($chkpass4);
			$pscount4 = $rowpass4['pscount4'];
		$chkfail4 = mysql_query("select count(fscore) as flcount4 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-04%' and fscore = 'FAIL' ");
			$rowfail4 = mysql_fetch_array($chkfail4);
			$flcount4 = $rowfail4['flcount4'];
		  
          echo "['April', ".$evcount4.", ".$pscount4.", ".$flcount4."], \n";
          
		  $chkagent5 = mysql_query("select count(distinct user) as agcount5 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-05%' ");
			$rowagent5 = mysql_fetch_array($chkagent5);
			$agcount5 = $rowagent5['agcount5'];
		$chkevals5 = mysql_query("select count(fscore) as evcount5 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-05%' and fscore != '(NULL)' ");
			$rowevals5 = mysql_fetch_array($chkevals5);
			$evcount5 = $rowevals5['evcount5'];
		$chkpass5 = mysql_query("select count(fscore) as pscount5 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-05%' and fscore = 'PASS' ");
			$rowpass5 = mysql_fetch_array($chkpass5);
			$pscount5 = $rowpass5['pscount5'];
		$chkfail5 = mysql_query("select count(fscore) as flcount5 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-05%' and fscore = 'FAIL' ");
			$rowfail5 = mysql_fetch_array($chkfail5);
			$flcount5 = $rowfail5['flcount5'];
		  
          echo "['May', ".$evcount5.", ".$pscount5.", ".$flcount5."], \n";
		  
		  $chkagent6 = mysql_query("select count(distinct user) as agcount6 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-06%' ");
			$rowagent6 = mysql_fetch_array($chkagent6);
			$agcount6 = $rowagent6['agcount6'];
		$chkevals6 = mysql_query("select count(fscore) as evcount6 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-06%' and fscore != '(NULL)' ");
			$rowevals6 = mysql_fetch_array($chkevals6);
			$evcount6 = $rowevals6['evcount6'];
		$chkpass6 = mysql_query("select count(fscore) as pscount6 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-06%' and fscore = 'PASS' ");
			$rowpass6 = mysql_fetch_array($chkpass6);
			$pscount6 = $rowpass6['pscount6'];
		$chkfail6 = mysql_query("select count(fscore) as flcount6 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-06%' and fscore = 'FAIL' ");
			$rowfail6 = mysql_fetch_array($chkfail6);
			$flcount6 = $rowfail6['flcount6'];
		  
          echo "['June', ".$evcount6.", ".$pscount6.", ".$flcount6."], \n";
          
		  $chkagent7 = mysql_query("select count(distinct user) as agcount7 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-07%' ");
			$rowagent7 = mysql_fetch_array($chkagent7);
			$agcount7 = $rowagent7['agcount7'];
		$chkevals7 = mysql_query("select count(fscore) as evcount7 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-07%' and fscore != '(NULL)' ");
			$rowevals7 = mysql_fetch_array($chkevals7);
			$evcount7 = $rowevals7['evcount7'];
		$chkpass7 = mysql_query("select count(fscore) as pscount7 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-07%' and fscore = 'PASS' ");
			$rowpass7 = mysql_fetch_array($chkpass7);
			$pscount7 = $rowpass7['pscount7'];
		$chkfail7 = mysql_query("select count(fscore) as flcount7 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-07%' and fscore = 'FAIL' ");
			$rowfail7 = mysql_fetch_array($chkfail7);
			$flcount7 = $rowfail7['flcount7'];
		  
          echo "['July', ".$evcount7.", ".$pscount7.", ".$flcount7."], \n";
          
		  $chkagent8 = mysql_query("select count(distinct user) as agcount8 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-08%' ");
			$rowagent8 = mysql_fetch_array($chkagent8);
			$agcount8 = $rowagent8['agcount8'];
		$chkevals8 = mysql_query("select count(fscore) as evcount8 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-08%' and fscore != '(NULL)' ");
			$rowevals8 = mysql_fetch_array($chkevals8);
			$evcount8 = $rowevals8['evcount8'];
		$chkpass8 = mysql_query("select count(fscore) as pscount8 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-08%' and fscore = 'PASS' ");
			$rowpass8 = mysql_fetch_array($chkpass8);
			$pscount8 = $rowpass8['pscount8'];
		$chkfail8 = mysql_query("select count(fscore) as flcount8 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-08%' and fscore = 'FAIL' ");
			$rowfail8 = mysql_fetch_array($chkfail8);
			$flcount8 = $rowfail8['flcount8'];
		  
          echo "['August', ".$evcount8.", ".$pscount8.", ".$flcount8."], \n";
          
		  $chkagent9 = mysql_query("select count(distinct user) as agcount9 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-09%' ");
			$rowagent9 = mysql_fetch_array($chkagent9);
			$agcount9 = $rowagent9['agcount9'];
		$chkevals9 = mysql_query("select count(fscore) as evcount9 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-09%' and fscore != '(NULL)' ");
			$rowevals9 = mysql_fetch_array($chkevals9);
			$evcount9 = $rowevals9['evcount9'];
		$chkpass9 = mysql_query("select count(fscore) as pscount9 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-09%' and fscore = 'PASS' ");
			$rowpass9 = mysql_fetch_array($chkpass9);
			$pscount9 = $rowpass9['pscount9'];
		$chkfail9 = mysql_query("select count(fscore) as flcount9 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-09%' and fscore = 'FAIL' ");
			$rowfail9 = mysql_fetch_array($chkfail9);
			$flcount9 = $rowfail9['flcount9'];
		  
          echo "['September', ".$evcount9.", ".$pscount9.", ".$flcount9."], \n";
          
		  $chkagent10 = mysql_query("select count(distinct user) as agcount10 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-10%' ");
			$rowagent10 = mysql_fetch_array($chkagent10);
			$agcount10 = $rowagent10['agcount10'];
		$chkevals10 = mysql_query("select count(fscore) as evcount10 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-10%' and fscore != '(NULL)' ");
			$rowevals10 = mysql_fetch_array($chkevals10);
			$evcount10 = $rowevals10['evcount10'];
		$chkpass10 = mysql_query("select count(fscore) as pscount10 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-10%' and fscore = 'PASS' ");
			$rowpass10 = mysql_fetch_array($chkpass10);
			$pscount10 = $rowpass10['pscount10'];
		$chkfail10 = mysql_query("select count(fscore) as flcount10 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-10%' and fscore = 'FAIL' ");
			$rowfail10 = mysql_fetch_array($chkfail10);
			$flcount10 = $rowfail10['flcount10'];
		  
          echo "['October', ".$evcount10.", ".$pscount10.", ".$flcount10."], \n";
		  
		  $chkagent11 = mysql_query("select count(distinct user) as agcount11 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-11%' ");
			$rowagent11 = mysql_fetch_array($chkagent11);
			$agcount11 = $rowagent11['agcount11'];
		$chkevals11 = mysql_query("select count(fscore) as evcount11 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-11%' and fscore != '(NULL)' ");
			$rowevals11 = mysql_fetch_array($chkevals11);
			$evcount11 = $rowevals11['evcount11'];
		$chkpass11 = mysql_query("select count(fscore) as pscount11 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-11%' and fscore = 'PASS' ");
			$rowpass11 = mysql_fetch_array($chkpass11);
			$pscount11 = $rowpass11['pscount11'];
		$chkfail11 = mysql_query("select count(fscore) as flcount11 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-11%' and fscore = 'FAIL' ");
			$rowfail11 = mysql_fetch_array($chkfail11);
			$flcount11 = $rowfail11['flcount11'];
		  
          echo "['November', ".$evcount11.", ".$pscount11.", ".$flcount11."], \n";
          
		  $chkagent12 = mysql_query("select count(distinct user) as agcount12 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-12%' ");
			$rowagent12 = mysql_fetch_array($chkagent12);
			$agcount12 = $rowagent12['agcount12'];
		$chkevals12 = mysql_query("select count(fscore) as evcount12 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-12%' and fscore != '(NULL)' ");
			$rowevals12 = mysql_fetch_array($chkevals12);
			$evcount12 = $rowevals12['evcount12'];
		$chkpass12 = mysql_query("select count(fscore) as pscount12 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-12%' and fscore = 'PASS' ");
			$rowpass12 = mysql_fetch_array($chkpass12);
			$pscount12 = $rowpass12['pscount12'];
		$chkfail12 = mysql_query("select count(fscore) as flcount12 from vicidial_agent_comments where campaign_id = '$campaign_id' and call_date like '".$currdt."-12%' and fscore = 'FAIL' ");
			$rowfail12 = mysql_fetch_array($chkfail12);
			$flcount12 = $rowfail12['flcount12'];
		  
		echo "['December', ".$evcount12.", ".$pscount12.", ".$flcount12."], \n";
		echo "]); \n";

		echo "var options = { \n";
			echo "width: '100%', \n";
			echo "legend: { position: 'none' }, \n";
			echo "chart: { \n";
			echo "title: '  QA Performance', \n";
		echo "}, \n";
			echo "colors: ['#ff4000', '#008c00', '#d90036'] \n";
		echo "}; \n";
		
		echo "google.charts.load('current', {'packages':['table']}); \n";
		echo "google.charts.setOnLoadCallback(drawTable1); \n";
		
		echo "var chart = new google.charts.Bar(document.getElementById('top_x_div".$cc."')); \n";
		echo "chart.draw(data, options); \n";
		echo "}; \n";
	  
		echo"function drawTable".$cc."() { \n";
			echo"var data = new google.visualization.DataTable(); \n";
			echo"data.addColumn('string', 'Overview'); \n";
			echo"data.addColumn('number', 'Jan'); \n";
			echo"data.addColumn('number', 'Feb'); \n";
			echo"data.addColumn('number', 'Mar'); \n";
			echo"data.addColumn('number', 'Apr'); \n";
			echo"data.addColumn('number', 'May'); \n";
			echo"data.addColumn('number', 'June'); \n";
			echo"data.addColumn('number', 'July'); \n";
			echo"data.addColumn('number', 'Aug'); \n";
			echo"data.addColumn('number', 'Sep'); \n";
			echo"data.addColumn('number', 'Oct'); \n";
			echo"data.addColumn('number', 'Nov'); \n";
			echo"data.addColumn('number', 'Dec'); \n";
			
			echo"data.addRows([ \n";
				echo"['Agents', {v: ".$agcount1."}, {v: ".$agcount2."}, {v: ".$agcount3."}, {v: ".$agcount4."}, {v: ".$agcount5."}, {v: ".$agcount6."}, {v: ".$agcount7."}, {v: ".$agcount8."}, {v: ".$agcount9."}, {v: ".$agcount10."}, {v: ".$agcount11."}, {v: ".$agcount12."}, ], \n";
				echo"['Evaluations', {v: ".$evcount1."}, {v: ".$evcount2."}, {v: ".$evcount3."}, {v: ".$evcount4."}, {v: ".$evcount5."}, {v: ".$evcount6."}, {v: ".$evcount7."}, {v: ".$evcount8."}, {v: ".$evcount9."}, {v: ".$evcount10."}, {v: ".$evcount11."}, {v: ".$evcount12."}, ], \n";
				echo"['Passes', {v: ".$pscount1."}, {v: ".$pscount2."}, {v: ".$pscount3."}, {v: ".$pscount4."}, {v: ".$pscount5."}, {v: ".$pscount6."}, {v: ".$pscount7."}, {v: ".$pscount8."}, {v: ".$pscount9."}, {v: ".$pscount10."}, {v: ".$pscount11."}, {v: ".$pscount12."}, ], \n";
				echo"['Fails', {v: ".$flcount1."}, {v: ".$flcount2."}, {v: ".$flcount3."}, {v: ".$flcount4."}, {v: ".$flcount5."}, {v: ".$flcount6."}, {v: ".$flcount7."}, {v: ".$flcount8."}, {v: ".$flcount9."}, {v: ".$flcount10."}, {v: ".$flcount11."}, {v: ".$flcount12."}, ], \n";
			echo"]); \n";
		
		/* echo "google.charts.load('current', {'packages':['table']}); \n";
		echo "google.charts.setOnLoadCallback(drawTableb1); \n"; */
		
		echo"var table = new google.visualization.Table(document.getElementById('table_div".$cc."')); \n";
		echo"var formatter = new google.visualization.ColorFormat(); \n";

		echo"table.draw(data, {showRowNumber: false, sort: 'disable', width: '100%', height: '100%'}); \n";
		echo"} \n";
		
		/* echo"function drawTableb".$cc."() { \n";
			echo"var data = new google.visualization.DataTable(); \n";
			echo"data.addColumn('string', 'Score'); \n";
			echo"data.addColumn('number', 'Pass/Fail'); \n";
			echo"data.addColumn('number', 'Total Pass'); \n";
			echo"data.addColumn('number', 'Total Fail'); \n";
			echo"data.addColumn('number', 'Total NA'); \n";
			echo"data.addColumn('number', 'Agent'); \n";
			echo"data.addColumn('number', 'Ingroup'); \n";
			echo"data.addColumn('number', 'Status'); \n";
			echo"data.addColumn('number', 'Camp ID'); \n";
			echo"data.addColumn('number', 'Comment Date'); \n";
			echo"data.addColumn('number', 'Call Date'); \n";
			echo"data.addColumn('number', 'Supervisor'); \n";
			echo"data.addColumn('number', 'Lead ID'); \n";
			echo"data.addColumn('number', 'Comment'); \n";
			
			echo"data.addRows([ \n";
				echo"['".$agcount1."', {v: ".$agcount1."}, {v: ".$agcount2."}, {v: ".$agcount3."}, {v: ".$agcount4."}, {v: ".$agcount5."}, {v: ".$agcount6."}, {v: ".$agcount7."}, {v: ".$agcount8."}, {v: ".$agcount9."}, {v: ".$agcount10."}, {v: ".$agcount11."}, {v: ".$agcount12."}, {v: ".$flcount12."}, ], \n";
				
			echo"]); \n";
		
		echo"var table = new google.visualization.Table(document.getElementById('table_divb".$cc."')); \n";
		echo"var formatter = new google.visualization.ColorFormat(); \n";

		echo"table.draw(data, {showRowNumber: true, sort: 'disable', width: '100%', height: '100%'}); \n";
		echo"} \n"; */
		$cc++;
		}
		
?>
</script>
<!-- google charts end -->
<script>
function printSheet() {
		var printButton = document.getElementById("printpagebutton");
		printButton.style.visibility = 'hidden';
		window.print();
		printButton.style.visibility = 'visible';
	}
</script>


</head>
<BODY BGCOLOR="white" marginheight="5" marginwidth="5" leftmargin="5" topmargin="5">
<CENTER>
<TABLE WIDTH="1366" BGCOLOR="#D9E6FE" cellpadding="10" cellspacing="0" border="0"> <!-- change table size here -->
	<TR BGCOLOR="#015B91">
		<TD ALIGN="LEFT">
			<a href="./admin.php"><FONT FACE="ARIAL,HELVETICA" COLOR="WHITE"><B>VICIDIAL ADMIN</a>: QA Reports - Yearly
		</TD>
		<TD ALIGN="RIGHT">
			<FONT FACE="ARIAL,HELVETICA" COLOR="WHITE"><B><?php echo date("l F j, Y G:i:s A") ?></font>
		</TD>
	</TR>  

	<?php
	
	/* table blocks start here */

	echo "<TR BGCOLOR=\"#F0F5FE\">\n";
		echo "<TD ALIGN=\"LEFT\" COLSPAN=\"2\">\n";
			echo "<FONT COLOR=\"BLACK\"><B>QA Reports</B>\n";
		echo "</TD>\n";
	echo "</TR>\n";
	echo "<TR>\n";
		echo "<TD ALIGN=LEFT COLSPAN=2>\n";
			
			echo "<TABLE width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" border = \"0\">\n";
				echo "<tr>\n";
					echo "<td align=center>\n";
							
						echo "<div id=\"tabs\" style =\"-webkit-border-radius: 10px;-moz-border-radius: 10px;border-radius: 10px;\">\n";
							echo "<ul>\n";
							
							$chkccount = mysql_query("SELECT DISTINCT campaign_id FROM vicidial_agent_comments WHERE call_date BETWEEN '$datefrom' AND '$dateto' ORDER BY campaign_id ");
							$tabtitle = 1;
							while($rowccount = mysql_fetch_array($chkccount)) {
								$campaign_id = $rowccount['campaign_id'];
								
								echo "<li><a href=\"#tabs-".$tabtitle."\">".$campaign_id."</a></li>\n";
								
							$tabtitle++;	
							}
								
							echo "</ul>\n";
							
							$tabfill = 1;
							while($tabfill <= $panelcount) {
								
								echo "<div id=\"tabs-".$tabfill."\">\n";
									echo "<div id=\"top_x_div".$tabfill."\" style=\"width: 100%; height: 300px;\"></div>\n";
									echo "<br> \n";
									echo "<div id=\"table_div".$tabfill."\" style=\"width: 100%;\"></div>\n";
									/* echo "<br> \n";
									echo "<div id=\"table_divb".$tabfill."\" style=\"width: 100%;\"></div>\n"; */
								echo "</div>\n";
							
							$tabfill++;
							
							}
							
						echo "</div>\n";
							
					echo "</td>\n";
				echo "</tr>\n";
				
				/* general report start here */
				
				echo "<tr>\n";
					echo "<td> \n";
					
						echo "<TABLE width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" border = \"1\" class=\"tblText\">\n";
							echo "<tr>\n";
								echo "<td align = \"center\" bgcolor = \"#004020\" colspan=\"25\">\n";
									echo "<b><font color = \"white\">OVERALL AGENT DETAIL</font></b> \n";
								echo "</td> \n";
							echo "</tr>\n";
							echo "<tr>\n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>No.</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Score</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Pass / Fail %</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Total Pass</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Total Fail</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Total NA</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Agent</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Ingroup</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Status</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Camp ID</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Comment Date</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Call Date</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Supervisor</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Lead ID</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Comments</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q1</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q2</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q3</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q4</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q5</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q6</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q7</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q8</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q9</b> \n";
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\">\n";
									echo "<b>Q10</b> \n";
								echo "</td> \n";
							echo "</tr>\n";
							
							$chkrept = mysql_query("SELECT * FROM vicidial_agent_comments WHERE fscore != '' AND call_date BETWEEN '$datefrom' AND '$dateto' ");
							
							$i = 1;
							while ($rowrept = mysql_fetch_array($chkrept)) {
								$full_name = $rowrept['full_name'];
								$fscore = $rowrept['fscore'];
								$rate01 = $rowrept['rate01'];
								$rate02 = $rowrept['rate02'];
								$rate03 = $rowrept['rate03'];
								$rate04 = $rowrept['rate04'];
								$rate05 = $rowrept['rate05'];
								$rate06 = $rowrept['rate06'];
								$rate07 = $rowrept['rate07'];
								$rate08 = $rowrept['rate08'];
								$rate09 = $rowrept['rate09'];
								$rate010 = $rowrept['rate010'];
								
								if ($rate01 == "PASS") {$pq1 = 1; $fq1 = 0; $nq1 = 0;} elseif ($rate01 == "FAIL") {$pq1 = 0; $fq1 = 1; $nq1 = 0;} elseif ($rate01 == "NA") {$pq1 = 0; $fq1 = 0; $nq1 = 1;} else {$pq1 = 0; $fq1 = 0; $nq1 = 0;}
								if ($rate02 == "PASS") {$pq2 = 1; $fq2 = 0; $nq2 = 0;} elseif ($rate02 == "FAIL") {$pq2 = 0; $fq2 = 1; $nq2 = 0;} elseif ($rate02 == "NA") {$pq2 = 0; $fq2 = 0; $nq2 = 1;} else {$pq2 = 0; $fq2 = 0; $nq2 = 0;}
								if ($rate03 == "PASS") {$pq3 = 1; $fq3 = 0; $nq3 = 0;} elseif ($rate03 == "FAIL") {$pq3 = 0; $fq3 = 1; $nq3 = 0;} elseif ($rate03 == "NA") {$pq3 = 0; $fq3 = 0; $nq3 = 1;} else {$pq3 = 0; $fq3 = 0; $nq3 = 0;}
								if ($rate04 == "PASS") {$pq4 = 1; $fq4 = 0; $nq4 = 0;} elseif ($rate04 == "FAIL") {$pq4 = 0; $fq4 = 1; $nq4 = 0;} elseif ($rate04 == "NA") {$pq4 = 0; $fq4 = 0; $nq4 = 1;} else {$pq4 = 0; $fq4 = 0; $nq4 = 0;}									
								if ($rate05 == "PASS") {$pq5 = 1; $fq5 = 0; $nq5 = 0;} elseif ($rate05 == "FAIL") {$pq5 = 0; $fq5 = 1; $nq5 = 0;} elseif ($rate05 == "NA") {$pq5 = 0; $fq5 = 0; $nq5 = 1;} else {$pq5 = 0; $fq5 = 0; $nq5 = 0;}									
								if ($rate06 == "PASS") {$pq6 = 1; $fq6 = 0; $nq6 = 0;} elseif ($rate06 == "FAIL") {$pq6 = 0; $fq6 = 1; $nq6 = 0;} elseif ($rate06 == "NA") {$pq6 = 0; $fq6 = 0; $nq6 = 1;} else {$pq6 = 0; $fq6 = 0; $nq6 = 0;}									
								if ($rate07 == "PASS") {$pq7 = 1; $fq7 = 0; $nq7 = 0;} elseif ($rate07 == "FAIL") {$pq7 = 0; $fq7 = 1; $nq7 = 0;} elseif ($rate07 == "NA") {$pq7 = 0; $fq7 = 0; $nq7 = 1;} else {$pq7 = 0; $fq7 = 0; $nq7 = 0;}									
								if ($rate08 == "PASS") {$pq8 = 1; $fq8 = 0; $nq8 = 0;} elseif ($rate08 == "FAIL") {$pq8 = 0; $fq8 = 1; $nq8 = 0;} elseif ($rate08 == "NA") {$pq8 = 0; $fq8 = 0; $nq8 = 1;} else {$pq8 = 0; $fq8 = 0; $nq8 = 0;}									
								if ($rate09 == "PASS") {$pq9 = 1; $fq9 = 0; $nq9 = 0;} elseif ($rate09 == "FAIL") {$pq9 = 0; $fq9 = 1; $nq9 = 0;} elseif ($rate09 == "NA") {$pq9 = 0; $fq9 = 0; $nq9 = 1;} else {$pq9 = 0; $fq9 = 0; $nq9 = 0;}									
								if ($rate010 == "PASS") {$pq10 = 1; $fq10 = 0; $nq10 = 0;} elseif ($rate010 == "FAIL") {$pq10 = 0; $fq10 = 1; $nq10 = 0;} elseif ($rate010 == "NA") {$pq10 = 0; $fq10 = 0; $nq10 = 1;} else {$pq10 = 0; $fq10 = 0; $nq10 = 0;}
								
								$tpass = ($pq1 + $pq2 + $pq3 + $pq4 + $pq5 + $pq6 + $pq7 + $pq8 + $pq9 + $pq10);
								$tfail = ($fq1 + $fq2 + $fq3 + $fq4 + $fq5 + $fq6 + $fq7 + $fq8 + $fq9 + $fq10);
								$tna = ($nq1 + $nq2 + $nq3 + $nq4 + $nq5 + $nq6 + $nq7 + $nq8 + $nq9 + $nq10);
								
								$ingroup = $rowrept['ingroup'];
								$call_status = $rowrept['call_status'];
								$campaign_id = $rowrept['campaign_id'];
								$supervisor_name = $rowrept['supervisor_name'];
								$comments = $rowrept['comments'];
								$comment_date = $rowrept['comment_date'];
								$call_date = $rowrept['call_date'];
								$lead_id = $rowrept['lead_id'];
								
								
							
							if ($i % 2 == 0) {
								$bgcolor = "#9BB9FB";
							} else {
								$bgcolor = "#B9CBFD";
							}
							
							echo "<tr bgcolor = \"".$bgcolor."\">\n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $i;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($fscore == "PASS") {
										echo "<font color=\"green\">".$fscore."</font> \n";
									} else {
										echo "<font color=\"red\">".$fscore."</font> \n";
									}									
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									/* $tpf = ($tpass / $tfail); */
									
									if (($tfail == 0) && ($tpass > 0)) {
										$tpf = 100;
									} elseif (($tfail > 0) && ($tpass > 0)) {
										$tcount = ($tfail + $tpass);
										$tpf = (($tpass / $tcount) * 100);
									} else {
										$tpf = 0;
									}
									
									/* echo round($tpf,2); */
									
									echo number_format((float)$tpf, 2, '.', '')."%";
									
									
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $tpass;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $tfail;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $tna;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $full_name;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $ingroup;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $call_status;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $campaign_id;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $comment_date;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $call_date;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $supervisor_name;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									echo $lead_id;
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									$comment = explode("*", $comments);
									echo $comment[0];
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate01 == "PASS") {
										echo "<font color = \"green\">".$rate01."</font> \n";
									} elseif ($rate01 == "NA") {
										echo "<font color = \"black\">".$rate01."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate01."</font> \n";
									}
									
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate02 == "PASS") {
										echo "<font color = \"green\">".$rate02."</font> \n";
									} elseif ($rate02 == "NA") {
										echo "<font color = \"black\">".$rate02."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate02."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate03 == "PASS") {
										echo "<font color = \"green\">".$rate03."</font> \n";
									} elseif ($rate03 == "NA") {
										echo "<font color = \"black\">".$rate03."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate03."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate04 == "PASS") {
										echo "<font color = \"green\">".$rate04."</font> \n";
									} elseif ($rate04 == "NA") {
										echo "<font color = \"black\">".$rate04."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate04."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate05 == "PASS") {
										echo "<font color = \"green\">".$rate05."</font> \n";
									} elseif ($rate05 == "NA") {
										echo "<font color = \"black\">".$rate05."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate05."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate06 == "PASS") {
										echo "<font color = \"green\">".$rate06."</font> \n";
									} elseif ($rate06 == "NA") {
										echo "<font color = \"black\">".$rate06."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate06."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate07 == "PASS") {
										echo "<font color = \"green\">".$rate07."</font> \n";
									} elseif ($rate07 == "NA") {
										echo "<font color = \"black\">".$rate07."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate07."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate08 == "PASS") {
										echo "<font color = \"green\">".$rate08."</font> \n";
									} elseif ($rate08 == "NA") {
										echo "<font color = \"black\">".$rate08."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate08."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate09 == "PASS") {
										echo "<font color = \"green\">".$rate09."</font> \n";
									} elseif ($rate09 == "NA") {
										echo "<font color = \"black\">".$rate09."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate09."</font> \n";
									}
								echo "</td> \n";
								echo "<td align = \"center\" valign = \"top\"> \n";
									if ($rate010 == "PASS") {
										echo "<font color = \"green\">".$rate010."</font> \n";
									} elseif ($rate010 == "NA") {
										echo "<font color = \"black\">".$rate010."</font> \n";
									} else {
										echo "<font color = \"red\">".$rate010."</font> \n";
									}
								echo "</td> \n";
							echo "</tr> \n";
							$i++;
							}
							
						echo "</table> \n";
					
					echo "</td> \n";
				echo "</tr>\n";
				
				/* general report end here */
				
				echo "<tr BGCOLOR=\"#015B91\">\n";
					echo "<td align=\"center\" colspan = \"5\">\n";
							echo "<input type =\"button\" onclick=\"location.href='AST_comments_reports.php'\" value=\"Back to Search\" class=\"NonPrintable\"/>\n";
							echo "<input id=\"printpagebutton\" type=\"button\" value=\"Print Report\" onclick=\"printSheet()\">\n";
					echo "</td>\n";
				echo "</tr>\n";
			echo "</TABLE>\n";
				
		echo "</td>\n";
	echo "</tr>\n";
echo "</TABLE>\n";
	
	
	
?>
<!-- main content ends here -->

</body>
</html>

