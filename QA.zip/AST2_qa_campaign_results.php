<?php
### AST2_qa_campaign_results.php
### 
# created 02-28-2017 Noel Cruz <noel@mycallcloud.com>
### 
### 

require("dbconnect.php");

/* include security script */
include("AST2_qa_sec.php");

/* POST, SESSION, and GET scripts go here */

/* print_r($_POST);
print_r($_GET);
print_r($_SESSION); */

if (isset($_GET["campaigns"]))				{$sent_campaigns=$_GET["campaigns"];}
	elseif (isset($_POST["campaigns"]))		{$sent_campaigns=$_POST["campaigns"];}

if (isset($_GET["datefrom"]))				{$sent_datefrom=$_GET["datefrom"];}
	elseif (isset($_POST["datefrom"]))		{$sent_datefrom=$_POST["datefrom"];}
	
if (isset($_GET["dateto"]))				{$sent_dateto=$_GET["dateto"];}
	elseif (isset($_POST["dateto"]))		{$sent_dateto=$_POST["dateto"];}
	
if (strpos($sent_datefrom, '/') !== false) {
  $sent_datefrom = str_replace('/', '-', date('Y-m-d', strtotime($_POST['datefrom'])))." 00:00:00";}
  
if (strpos($sent_dateto, '/') !== false) {
  $sent_dateto = str_replace('/', '-', date('Y-m-d', strtotime($_POST['dateto'])))." 23:59:59";}

if (isset($_GET["pagestart"]))				{$pagestart=$_GET["pagestart"];}
	elseif (isset($_POST["pagestart"]))		{$pagestart=$_POST["pagestart"];}
	
if (isset($_GET["pagemax"]))				{$pagemax=$_GET["pagemax"];}
	elseif (empty($pagemax))		{$pagemax=$_POST["pagemax"];}
	elseif (isset($_POST["pagemax"]))		{$pagemax=$_POST["pagemax"];}
	
?>
<html>
<head>
<title></title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<link href="https://fonts.googleapis.com/css?family=News+Cycle:400,700" rel="stylesheet">
<style type="text/css">
	html body, {
		font-family: 'News Cycle'; 
		font-size: 13.5px;
	}
	tr.listing:hover {
		background-color: #cccccc;
	}
	table {
		width: 100%;
		font-family: 'News Cycle'; 
		font-size: 13.5px;
	}
	.scroll {
		max-height: 610px;
		overflow: auto;
	}
</style>

<!-- audio player js script start -->
<script src="styles/audio.min2.js"></script>
<!-- audio player js script end -->

</head>
<body bgcolor="#d9e6fe" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">

	<?php
	/* echo "<form action=\"AST2_qa_campaign_results.php\" method=\"post\">\n"; */
	echo "<table width=\"100%\" bgcolor=\"#d9e6fe\" cellpadding=\"3\" cellspacing=\"0\" align=\"center\" border=\"0\">\n";
	//results panel start
	
	/* select data from table using campaign and date range post value start*/
					
	if (($pagemax == "all") && ($sent_campaigns == "allcamps")) {
		$chkcampaign = mysql_query("select * from vicidial_agent_comments where call_date between '$sent_datefrom' and '$sent_dateto' ");
	} elseif (($pagemax == "all") && ($sent_campaigns != "allcamps")) {
		$chkcampaign = mysql_query("select * from vicidial_agent_comments where campaign_id = '$sent_campaigns' and call_date between '$sent_datefrom' and '$sent_dateto' ");
	} elseif ($sent_campaigns == "allcamps") {
		$chkcampaign = mysql_query("select * from vicidial_agent_comments where call_date between '$sent_datefrom' and '$sent_dateto' limit ".$pagestart.", ".$pagemax." ");
	} else {
		$chkcampaign = mysql_query("select * from vicidial_agent_comments where campaign_id = '$sent_campaigns' and call_date between '$sent_datefrom' and '$sent_dateto' limit ".$pagestart.", ".$pagemax." ");
	}
	
		echo "<tr>\n";
			echo "<th align=\"left\" bgcolor=\"#9BB9FB\" colspan = \"10\">\n";
			/* count results */
			if ($sent_campaigns == "allcamps") {
				$chkentrycount = mysql_query("select count(*) as entry_count from vicidial_agent_comments where call_date between '$sent_datefrom' and '$sent_dateto' ");
				$rowentrycount = mysql_fetch_array($chkentrycount);
				$entry_count = $rowentrycount['entry_count'];
				$camptitle = "All Campaigns";
			} else {
				$chkentrycount = mysql_query("select count(*) as entry_count from vicidial_agent_comments where campaign_id = '$sent_campaigns' and call_date between '$sent_datefrom' and '$sent_dateto' ");
				$rowentrycount = mysql_fetch_array($chkentrycount);
				$entry_count = $rowentrycount['entry_count'];
				$camptitle = $sent_campaigns;
			}
					
				echo "<b>Search By ".$camptitle." - ".number_format($entry_count)," Records found. From ".$sent_datefrom." to ".$sent_dateto.". 50 records shown per page.</b>\n";
			echo "</th>\n";
		echo "</tr>\n";

		echo "<tr bgcolor=\"#015B91\">\n";
			echo "<td align = \"center\" width=\"45\"><font color = \"white\"><b>No.</b></font></td>\n";
			echo "<td align = \"center\" width=\"153\"><font color = \"white\"><b>Call Date/Time</b></font></td>\n";
			echo "<td align = \"center\" width=\"117\"><font color = \"white\"><b>Call Length</b></font></td>\n";
			echo "<td align = \"center\" width=\"105\"><font color = \"white\"><b>Campaign</b></font></td>\n";
			echo "<td align = \"center\" width=\"160\"><font color = \"white\"><b>Agent ID/Name</b></font></td>\n";
			echo "<td align = \"center\" width=\"109\"><font color = \"white\"><b>Call Status</b></font></td>\n";
			echo "<td align = \"center\" width=\"118\"><font color = \"white\"><b>User Group</b></font></td>\n";
			echo "<td align = \"center\" width=\"85\"><font color = \"white\"><b>InGroup</b></font></td>\n";
			echo "<td align = \"center\" width=\"95\"><font color = \"white\"><b>Evaluator</b></font></td>\n";
			echo "<td align = \"center\"><font color = \"white\"><b>Action</b></font></td>\n";
		echo "</tr>\n";
	echo "</table>\n";

	echo "<div class=\"scroll\">\n"; 			//make the table scrollable
	echo "<table width=\"100%\" bgcolor=\"#d9e6fe\" cellpadding=\"3\" cellspacing=\"0\" align=\"center\" border=\"0\">\n";
		if ($pagestart == 0) {
			$i = 1;
		} else {
			$i = ($pagestart + 1);
		}
		
		while($rowcampaign = mysql_fetch_array($chkcampaign)) {
			$lead_id = $rowcampaign['lead_id'];
			$call_date = $rowcampaign['call_date'];
			$campaign_id = $rowcampaign['campaign_id'];
			$user = $rowcampaign['user'];
			$full_name = $rowcampaign['full_name'];
			$call_status = $rowcampaign['call_status'];
			$user_group = $rowcampaign['user_group'];
			$ingroup = $rowcampaign['ingroup'];
			$supervisor_name = $rowcampaign['supervisor_name'];
			$uniqueid = $rowcampaign['uniqueid'];
			$comments = $rowcampaign['comments'];
									
			if ($i % 2 == 0) {
				$bgcolor = "#9BB9FB";
			} else {
				$bgcolor = "#B9CBFD";
			}
									
			echo "<tr class = \"listing\" bgcolor = \"".$bgcolor."\">\n";	
		
			/* Start numbering */
			echo "<td align=\"center\" width=\"45\">\n";
				echo $i."\n";
			echo "</td>\n";
									
			/* start listing call date */
			echo "<td align=\"center\" width=\"153\">\n";
				echo $call_date."\n";
			echo "</td>\n";
									
			/* start listing call length */
			$chkcall_length = mysql_query("select length_in_sec from recording_log where lead_id = '$lead_id' and user = '$user' ");
			$rowcall_legnth = mysql_fetch_array($chkcall_length);
			$callchktime = $rowcall_legnth['length_in_sec'];
			$call_length = gmdate("H:i:s", $callchktime);
									
			echo "<td align=\"center\" width=\"117\">\n";
				echo $call_length."\n";
			echo "</td>\n";
									
			/* start listing campaign_id */
			echo "<td align=\"center\" width=\"105\">\n";
				echo $campaign_id."\n";
			echo "</td>\n";
									
			/* start listing agent id and name */
			echo "<td align=\"center\" width=\"160\">\n";
				echo $user." - ".$full_name."\n";
			echo "</td>\n";
									
			/* start listing call status */
			echo "<td align=\"center\" width=\"109\">\n";
				echo $call_status."\n";
			echo "</td>\n";
									
			/* star listing user group */
			echo "<td align=\"center\" width=\"118\">\n";
				echo $user_group."\n";
			echo "</td>\n";
									
			/* start listing ingroup */
			echo "<td align=\"center\" width=\"85\">\n";
				echo $ingroup."\n";
			echo "</td>\n";
			
			/* start listing evaluator/supervisor */
			echo "<td align=\"center\" width=\"95\">\n";
				echo $supervisor_name."\n";
			echo "</td>\n";
			
			/* start listing if record is reviewable or reviewed */
			$chkfile = mysql_query("SELECT * FROM recording_log WHERE lead_id = '$lead_id' AND user = '$agent' ");
			$rowfile = mysql_fetch_array($chkfile);
			$callfile = $rowfile['filename'];
			$callurl = $rowfile['location'];
							
			if (!empty($comments)) { 			//if the call was already evaluated
				
			/* modal script goes here from w3schools [https://www.w3schools.com/howto/howto_css_modals.asp]  */
			/* this was supposed to go at the <head> section but will not function if the modal is in a loopy loop */
			/* so this was treated as part of the loop with identifiers per class/id */
			
			echo "<style>\n";
			/* The Modal (background) */
			echo ".modal".$lead_id." {\n";
				echo "display: none;\n"; /* Hidden by default */
				echo "position: fixed;\n"; /* Stay in place */
				echo "z-index: 1;\n"; /* Sit on top */
				echo "padding-top: 5px;\n"; /* Location of the box */
				echo "left: 0;\n";
				echo "top: 0;\n";
				echo "width: 100%;\n"; /* Full width */
				echo "height: 100%;\n"; /* Full height */
				echo "overflow: auto;\n"; /* Enable scroll if needed */
				echo "background-color: rgb(0,0,0);\n"; /* Fallback color */
				echo "background-color: rgba(0,0,0,0.4);\n"; /* Black w/ opacity */
			echo "}\n";

			/* Modal Content */
			echo ".modal".$lead_id."-content {\n";
				echo "position: relative;\n";
				echo "background-color: #d9e6fe;\n";
				echo "margin: auto;\n";
				echo "padding: 0;\n";
				echo "border: 1px solid #888;\n";
				echo "width: 1120px;\n";
				echo "box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);\n";
				echo "-webkit-animation-name: animatetop;\n";
				echo "-webkit-animation-duration: 0.8s;\n";
				echo "animation-name: animatetop;\n";
				echo "animation-duration: 0.8s\n";
			echo "}\n";

			/* Add Animation */
			echo "@-webkit-keyframes animatetop {\n";
				echo "from {top:-800px; opacity:0} \n";
				echo "to {top:0; opacity:1}\n";
			echo "}\n";

			echo "@keyframes animatetop {\n";
				echo "from {top:-300px; opacity:0}\n";
				echo "to {top:0; opacity:1}\n";
			echo "}\n";

			/* The Close Button */
			echo ".close".$lead_id." {\n";
				echo "color: white;\n";
				echo "float: right;\n";
				echo "font-size: 15px;\n";
				echo "font-weight: bold;\n";
				echo "padding: 0 0 0 0;\n";
				echo "margin-top: -3px;\n";
			echo "}\n";

			echo ".close".$lead_id.":hover,\n";
			echo ".close".$lead_id.":focus {\n";
				echo "color: red;\n";
				echo "text-decoration: none;\n";
				echo "cursor: pointer;\n";
				echo "padding: 0 0 0 0;\n";
				echo "margin-top: -3px;\n";
			echo "}\n";

			echo ".modal".$lead_id."-header {\n";
				echo "padding: 2px 5px;\n";
				echo "background-color: #015B91;\n";
				echo "color: white;\n";
				echo "text-align: left;\n";
			echo "}\n";

			echo ".modal".$lead_id."-body {padding: 5px 16px;}\n";

			echo ".modal".$lead_id."-footer {\n";
				echo "padding: 2px 0 2px 0;\n";
				echo "background-color: #015B91;\n";
				echo "color: white;\n";
			echo "}\n";
			echo "</style>\n";
			
			echo "<td align=\"center\">\n";

				echo "<input type=\"button\" id=\"myBtn".$lead_id."\" value=\"Review\">\n";
				
				/* <!-- Trigger/Open The Modal --> */

				/* <!-- The Modal --> */
				echo "<div id=\"myModal".$lead_id."\" class=\"modal".$lead_id."\">\n";

					/* <!-- Modal content --> */
					echo "<div class=\"modal".$lead_id."-content\">\n";
						echo "<div class=\"modal".$lead_id."-header\">\n";
							echo "<span class=\"close".$lead_id."\">close</span>\n";
							echo "<b>Evaluation for: ".$user." - ".$full_name."</b>\n";
						echo "</div>\n";
						echo "<div class=\"modal".$lead_id."-body\">\n";
						
						/* scoresheet table goes in here */
						
							echo "<table width = \"100\" align=\"center\" cellpadding=\"5\" cellspacing=\"0\" border = \"1\">\n";
								echo "<tr>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
								echo "</tr>\n";
								echo "<tr>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
								echo "</tr>\n";
								echo "<tr>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
									echo "<td>test</td>\n";
								echo "</tr>\n";
							echo "</table>\n";
							
							/* scoresheet table ends here */
							
						echo "</div>\n";
						echo "<div class=\"modal".$lead_id."-footer\">\n";
							echo "<input type=\"button\" value=\"Print\">\n";	//add js code for print here
						echo "</div>\n";
    
					echo "</div>\n";

				echo "</div>\n";

				echo "<script>\n";
				// Get the modal
				echo "var modal".$lead_id." = document.getElementById('myModal".$lead_id."');\n";

				// Get the link that opens the modal
				echo "var btn".$lead_id." = document.getElementById(\"myBtn".$lead_id."\");\n";

				// Get the <span> element that closes the modal
				echo "var span = document.getElementsByClassName(\"close".$lead_id."\")[0];\n";

				// When the user clicks the button, open the modal 
				echo "btn".$lead_id.".onclick = function() {\n";
					echo "modal".$lead_id.".style.display = \"block\";\n";
				echo "}\n";

				// When the user clicks on <span> (close), close the modal
				echo "span.onclick = function() {\n";
					echo "modal".$lead_id.".style.display = \"none\";\n";
				echo "}\n";

				// When the user clicks anywhere outside of the modal, close it
				echo "window.onclick = function(event) {\n";
					echo "if (event.target != modal".$lead_id.") {\n";
						echo "modal".$lead_id.".style.display = \"none\";\n";
					echo "}\n";
				echo "}\n";
				echo "</script>	\n";
			
			/* modal script ends here */
				
			echo "</td>\n";

			} elseif (empty($comments)) { 		//if the call has not been evaluated
			
			/* modal script goes here from w3schools [https://www.w3schools.com/howto/howto_css_modals.asp]  */
			/* this was supposed to go at the <head> section but will not function if the modal is in a loopy loop */
			/* so this was treated as part of the loop with identifiers per class/id */
			
			echo "<style>\n";
			/* The Modal (background) */
			echo ".modal".$lead_id." {\n";
				echo "display: none;\n"; /* Hidden by default */
				echo "position: fixed;\n"; /* Stay in place */
				echo "z-index: 1;\n"; /* Sit on top */
				echo "padding-top: 5px;\n"; /* Location of the box */
				echo "left: 0;\n";
				echo "top: 0;\n";
				echo "width: 100%;\n"; /* Full width */
				echo "height: 100%;\n"; /* Full height */
				echo "overflow: auto;\n"; /* Enable scroll if needed */
				echo "background-color: rgb(0,0,0);\n"; /* Fallback color */
				echo "background-color: rgba(0,0,0,0.4);\n"; /* Black w/ opacity */
			echo "}\n";

			/* Modal Content */
			echo ".modal".$lead_id."-content {\n";
				echo "position: relative;\n";
				echo "background-color: #d9e6fe;\n";
				echo "margin: 0 0 0 0;\n";
				echo "padding: 0 0 0 0;\n";
				echo "border: 1px solid #888;\n";
				echo "width: 1130px;\n";
				echo "height: 660px;\n";
				echo "box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);\n";
				echo "-webkit-animation-name: animatetop;\n";
				echo "-webkit-animation-duration: 0.8s;\n";
				echo "animation-name: animatetop;\n";
				echo "animation-duration: 0.8s\n";
			echo "}\n";

			/* Add Animation */
			echo "@-webkit-keyframes animatetop {\n";
				echo "from {top:-800px; opacity:0} \n";
				echo "to {top:0; opacity:1}\n";
			echo "}\n";

			echo "@keyframes animatetop {\n";
				echo "from {top:-300px; opacity:0}\n";
				echo "to {top:0; opacity:1}\n";
			echo "}\n";

			/* The Close Button */
			echo ".close".$lead_id." {\n";
				echo "color: white;\n";
				echo "float: right;\n";
				echo "font-size: 15px;\n";
				echo "font-weight: bold;\n";
				echo "padding: 0 0 0 0;\n";
				echo "margin-top: -3px;\n";
			echo "}\n";

			echo ".close".$lead_id.":hover,\n";
			echo ".close".$lead_id.":focus {\n";
				echo "color: red;\n";
				echo "text-decoration: none;\n";
				echo "cursor: pointer;\n";
				echo "padding: 0 0 0 0;\n";
				echo "margin-top: -3px;\n";
			echo "}\n";

			echo ".modal".$lead_id."-header {\n";
				echo "padding: 2px 5px;\n";
				echo "background-color: #015B91;\n";
				echo "color: white;\n";
				echo "text-align: left;\n";
			echo "}\n";

			echo ".modal".$lead_id."-body {padding: 5px 5px;}\n";

			echo ".modal".$lead_id."-footer {\n";
				echo "padding: 2px 0 2px 0;\n";
				echo "background-color: #015B91;\n";
				echo "color: white;\n";
			echo "}\n";
			echo "</style>\n";
			
			echo "<td align=\"center\">\n";

				echo "<input type=\"button\" id=\"myBtn".$lead_id."\" value=\"Evaluate\">\n";
				
				/* <!-- Trigger/Open The Modal --> */

				/* <!-- The Modal --> */
				echo "<div id=\"myModal".$lead_id."\" class=\"modal".$lead_id."\">\n";

					/* <!-- Modal content --> */
					echo "<div class=\"modal".$lead_id."-content\">\n";
						echo "<div class=\"modal".$lead_id."-header\">\n";
							echo "<span class=\"close".$lead_id."\">close</span>\n";
							echo "<b>Evaluation for: ".$user." - ".$full_name."</b>\n";
						echo "</div>\n";
						echo "<div class=\"modal".$lead_id."-body\">\n";
						
						/* scoresheet table goes in here */
						
							echo "<table width = \"800\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" bgcolor = \"#d9e6fe\" border = \"0\">\n";
								echo "<tr>\n";
									echo "<td align=\"center\"><b>Unique ID</b></td>\n";
									echo "<td align=\"center\"><b>Campaign ID</b></td>\n";
									echo "<td align=\"center\"><b>InGroup</b></td>\n";
									echo "<td align=\"center\"><b>Lead ID</b></td>\n";
									echo "<td align=\"center\"><b>Call Date</b></td>\n";
									echo "<td align=\"center\"><b>Evaluation Date</b></td>\n";
									echo "<td align=\"center\"><b>Phone No.</b></td>\n";
									echo "<td align=\"center\"><b>Evaluator</b></td>\n";
								echo "</tr>\n";
								echo "<tr bgcolor=\"#9BB9FB\">\n";
									echo "<td align=\"center\">".$uniqueid."</td>\n";
									echo "<td align=\"center\">".$campaign_id."</td>\n";
									echo "<td align=\"center\">".$ingroup."</td>\n";
									echo "<td align=\"center\">".$lead_id."</td>\n";
									echo "<td align=\"center\">".$call_date."</td>\n";
									echo "<td align=\"center\">".$comment_date."</td>\n";
									
									/* get phone number dialled from vicidial_list */
									$chkpn = mysql_query("select phone_number from vicidial_list where lead_id = '$lead_id' ");
										$rowpn = mysql_fetch_array($chkpn);
										$phone_number = $rowpn['phone_number'];
									
									echo "<td align=\"center\">".$phone_number."</td>\n";
									echo "<td align=\"center\">".$supervisor_id."</td>\n";
								echo "</tr>\n";
								
								echo "<tr>\n";
									echo "<td align=\"center\" colspan = \"8\" valign = \"top\">\n";
										echo "<table width = \100%\" cellpadding = \"0\" cellspacing = \"0\" align = \"center\" border =\"0\">\n";
										
											echo "<tr>\n";
												echo "<td align=\"center\" valign = \"top\">\n";
													echo "<iframe allowtransparency=\"true\" src=\"AST2_qa_scores.php?user=".$user."&full_name=".$full_name."&campaign_id=".$campaign_id."&uniqueid=".$uniqueid."&ingroup=".$ingroup."&lead_id=".$lead_id."&call_date=".$call_date."&comment_date=".$comment_date."&phone_number=".$phone_number."&supervisor_id=".$supervisor_id."\" width=\"100%\" height=\"550\" frameborder=\"0\" style=\"background-color: #D9E6FE;\" scrolling=\"yes\"></iframe> \n";
												echo "</td>\n";
											echo "</tr>\n";
											
										echo "</table>\n";
									echo "</td>\n";
								echo "</tr>\n";
							echo "</table>\n";
							
							/* scoresheet table ends here */
							
						echo "</div>\n";
						echo "<div class=\"modal".$lead_id."-footer\">\n";
							echo "<input type=\"button\" value=\"Print\">\n";	//add js code for print here
						echo "</div>\n";
    
					echo "</div>\n";

				echo "</div>\n";

				echo "<script>\n";
				// Get the modal
				echo "var modal".$lead_id." = document.getElementById('myModal".$lead_id."');\n";

				// Get the link that opens the modal
				echo "var btn".$lead_id." = document.getElementById(\"myBtn".$lead_id."\");\n";

				// Get the <span> element that closes the modal
				echo "var span".$lead_id." = document.getElementsByClassName(\"close".$lead_id."\")[0];\n";

				// When the user clicks the button, open the modal 
				echo "btn".$lead_id.".onclick = function() {\n";
					echo "modal".$lead_id.".style.display = \"block\";\n";
				echo "}\n";

				// When the user clicks on <span> (close), close the modal
				echo "span".$lead_id.".onclick = function() {\n";
					echo "modal".$lead_id.".style.display = \"none\";\n";
				echo "}\n";

				// When the user clicks anywhere outside of the modal, close it
				echo "window.onclick = function(event) {\n";
					echo "if (event.target == modal".$lead_id.") {\n";
						echo "modal".$lead_id.".style.display = \"none\";\n";
					echo "}\n";
				echo "}\n";
				echo "</script>	\n";
			
			/* modal script ends here */
			
			echo "</td>\n";

			} else {
			echo "<td align=\"center\">\n";
				echo "Audio File Not Found \n";
			echo "</td>\n";
			}
			
		echo "</tr>\n";

		$i++;
		}
		
		/* begin entry count */
		if ($sent_campaigns == "allcamps") {
			$chkpagecount = mysql_query("select count(*) as maxcount from vicidial_agent_comments where call_date between '$sent_datefrom' and '$sent_dateto' ");
		} else {
			$chkpagecount = mysql_query("select count(*) as maxcount from vicidial_agent_comments where campaign_id = '$sent_campaigns' and call_date between '$sent_datefrom' and '$sent_dateto' ");
		}

		$rowpagecount = mysql_fetch_array($chkpagecount);
		$maxcount = $rowpagecount['maxcount'];
		
		/* get total number of paging */
		$pagecount = ($maxcount / $pagemax);
		
		/* round-down page count */
		$pagecountmin = round($pagecount, 0, PHP_ROUND_HALF_DOWN);
		
		/* determine maximum page start (limit) for the search */
		$maxpagestart = ($pagecountmin * 50);
		
		echo "<tr>\n";
			echo "<td align=\"center\" bgcolor=\"#015B91\" colspan = \"10\">\n";
				echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign.php'\" value=\"Back to Search\" />\n";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
				
				/* begin pagination script */
				if ($pagestart > 0){
					$newpagestart = ($pagestart + 50);
					$prevpage = ($pagestart - 50);
					
				/* check and stop pagination if limits reached */
					if ($newpagestart < $maxpagestart) {
						
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=0&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"First\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$prevpage."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Previous\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$newpagestart."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Next\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$maxpagestart."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Last\"/>\n";
						
					} elseif ($newpagestart >= $maxpagestart) {
						
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=0&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"First\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$prevpage."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Previous\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Next\" disabled/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Last\" disabled/>\n";
						
					}
		
				} else {
					$newpagestart = ($pagestart + 50);
					
					if ($pagemax == "all") {
						
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=0&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"First\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Previous\" disabled/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Next\" disabled/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Last\" disabled/>\n";
						
					} else {
						
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"First\" disabled/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php'\" value=\"Previous\" disabled/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$newpagestart."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Next\"/>\n";
						echo "<input type =\"button\" onclick=\"location.href='AST2_qa_campaign_results.php?pagestart=".$maxpagestart."&pagemax=50&campaigns=".$sent_campaigns."&datefrom=".$sent_datefrom."&dateto=".$sent_dateto."'\" value=\"Last\"/>\n";
						
					}
				}
				
			echo "</td>\n";
		echo "</tr>\n";
		
	echo "</table>\n";	
	echo "</div>\n";

	?>
	/* </form> */

	<!-- audio player script start -->
	<script>
	audiojs.events.ready(function() {
		var as = audiojs.createAll();
	});
	</script>
	<!-- audio player script end -->
	
</body>
</html>
